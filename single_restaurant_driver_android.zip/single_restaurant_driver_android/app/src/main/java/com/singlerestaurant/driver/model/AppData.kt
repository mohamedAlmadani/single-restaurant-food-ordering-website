package com.singlerestaurant.driver.model

import com.google.gson.annotations.SerializedName

data class AppData(

	@field:SerializedName("copyright")
	val copyright: String? = null,

	@field:SerializedName("og_title")
	val ogTitle: String? = null,

	@field:SerializedName("timezone")
	val timezone: String? = null,

	@field:SerializedName("android")
	val android: String? = null,

	@field:SerializedName("created_at")
	val createdAt: String? = null,

	@field:SerializedName("ios")
	val ios: String? = null,

	@field:SerializedName("title")
	val title: String? = null,

	@field:SerializedName("twitter")
	val twitter: String? = null,

	@field:SerializedName("short_title")
	val shortTitle: String? = null,

	@field:SerializedName("updated_at")
	val updatedAt: String? = null,

	@field:SerializedName("og_description")
	val ogDescription: String? = null,

	@field:SerializedName("max_order_qty")
	val maxOrderQty: String? = null,

	@field:SerializedName("referral_amount")
	val referralAmount: String? = null,

	@field:SerializedName("logo")
	val logo: String? = null,

	@field:SerializedName("currency")
	val currency: String? = null,

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("lang")
	val lang: String? = null,

	@field:SerializedName("map")
	val map: String? = null,

	@field:SerializedName("email")
	val email: String? = null,

	@field:SerializedName("lat")
	val lat: String? = null,

	@field:SerializedName("verification")
	val verification: String? = null,

	@field:SerializedName("insta")
	val insta: String? = null,

	@field:SerializedName("image")
	val image: String? = null,

	@field:SerializedName("address")
	val address: String? = null,

	@field:SerializedName("favicon")
	val favicon: String? = null,

	@field:SerializedName("mobile")
	val mobile: String? = null,

	@field:SerializedName("current_version")
	val currentVersion: String? = null,

	@field:SerializedName("firebase")
	val firebase: String? = null,

	@field:SerializedName("about_content")
	val aboutContent: String? = null,

	@field:SerializedName("currency_position")
	val currencyPosition: String? = null,

	@field:SerializedName("og_image")
	val ogImage: String? = null,

	@field:SerializedName("min_order_amount")
	val minOrderAmount: String? = null,

	@field:SerializedName("delivery_charge")
	val deliveryCharge: String? = null,

	@field:SerializedName("max_order_amount")
	val maxOrderAmount: String? = null,

	@field:SerializedName("footer_logo")
	val footerLogo: String? = null,

	@field:SerializedName("fb")
	val fb: String? = null
)
