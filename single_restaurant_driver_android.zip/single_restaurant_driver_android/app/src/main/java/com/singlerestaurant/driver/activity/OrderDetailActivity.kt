package com.singlerestaurant.driver.activity

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.singlerestaurant.driver.R
import com.singlerestaurant.driver.api.ApiClient
import com.singlerestaurant.driver.api.SingleResponse
import com.singlerestaurant.driver.base.BaseActivity
import com.singlerestaurant.driver.base.BaseAdaptor
import com.singlerestaurant.driver.databinding.ActOrderdetailBinding
import com.singlerestaurant.driver.model.OrderDetailResponse
import com.singlerestaurant.driver.utils.Common
import com.singlerestaurant.driver.utils.Common.showLoadingProgress
import com.singlerestaurant.driver.utils.SharePreference
import com.singlerestaurant.driver.utils.SharePreference.Companion.getStringPref
import com.singlerestaurant.driver.utils.SharePreference.Companion.isCurrancy
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.singlerestaurant.driver.fragment.FragAddons
import com.singlerestaurant.driver.model.OrderData
import com.singlerestaurant.driver.model.OrderDetailData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class OrderDetailActivity : BaseActivity() {
    var orderId = ""
    var orderStatus = ""
    var paymentType = ""
    var orderDate = ""
    var currency=""
    var currencyPos=""
    private lateinit var binding: ActOrderdetailBinding

    override fun setLayout() = binding.root

    override fun initView() {
        binding = ActOrderdetailBinding.inflate(layoutInflater)
        currency= getStringPref(this@OrderDetailActivity, isCurrancy) ?:""
        currencyPos= getStringPref(this@OrderDetailActivity,SharePreference.currencyPos) ?:""
        Common.getCurrentLanguage(this@OrderDetailActivity, false)
        if (Common.isCheckNetwork(this@OrderDetailActivity)) {
            callApiOrderDetail()
        } else {
            Common.alertErrorOrValidationDialog(this@OrderDetailActivity, resources.getString(R.string.no_internet))
        }



        orderStatus = intent.getStringExtra("status").toString()
        paymentType = intent.getStringExtra("paymentType").toString()
        orderDate = intent.getStringExtra("orderDate").toString()
        orderId = intent.getStringExtra("order_number").toString()
        binding.ivBack.setOnClickListener {
            finish()
        }

        if (getStringPref(this@OrderDetailActivity, SharePreference.SELECTED_LANGUAGE).equals(resources.getString(R.string.language_hindi))) {
            binding.ivBack.rotation = 180F
        } else {
            binding.ivBack.rotation = 0F
        }

    }


    override fun onBackPressed() {
        finish()
    }


    @SuppressLint("NewApi")
    private fun orderInfo(response :OrderDetailData) {

        when {
            paymentType.toInt() == 1 -> {
                binding.cellOrderHistory.tvPaymentType.text = resources.getString(R.string.payment_type_)
                    .plus("  ${resources.getString(R.string.cash)}")
            }
            paymentType.toInt() == 3 -> {
                binding.cellOrderHistory.tvPaymentType.text = resources.getString(R.string.payment_type_)
                    .plus("  ${resources.getString(R.string.razorpay)}")
            }
            paymentType.toInt() == 4 -> {
                binding.cellOrderHistory.tvPaymentType.text = resources.getString(R.string.payment_type_)
                    .plus("  ${resources.getString(R.string.stripe)}")
            }
            paymentType.toInt() == 5 -> {
                binding.cellOrderHistory.tvPaymentType.text = resources.getString(R.string.payment_type_)
                    .plus("  ${resources.getString(R.string.flutter_wave)}")
            }
            paymentType.toInt() == 6 -> {
                binding.cellOrderHistory.tvPaymentType.text = resources.getString(R.string.payment_type_)
                    .plus("  ${resources.getString(R.string.paystack)}")
            }

            else -> {
                binding.cellOrderHistory.tvPaymentType.text = resources.getString(R.string.payment_type_).plus("  ${resources.getString(R.string.wallet)}")
            }
        }

        binding.cellOrderHistory.tvOrderDate.text = orderDate
        binding.cellOrderHistory.tvOrderNumber.text = "#${orderId}"
        binding.cellOrderHistory.tvPrice.text =Common.getPrice(currencyPos,currency,response.summery?.grandTotal?:"0.00")

        when (orderStatus) {
            "4" -> {
                binding.cellOrderHistory.tvOrderStatus.backgroundTintList =
                    ColorStateList.valueOf(
                        ResourcesCompat.getColor(
                            resources,
                            R.color.blue,
                            null
                        )
                    )
                binding.cellOrderHistory.tvOrderStatus.text =
                    resources.getString(R.string.on_the_way)
            }
            "5" -> {
                binding.cellOrderHistory.tvOrderStatus.backgroundTintList =
                    ColorStateList.valueOf(
                        ResourcesCompat.getColor(
                            resources,
                            R.color.light_green,
                            null
                        )
                    )
                binding.cellOrderHistory.tvOrderStatus.text = resources.getString(R.string.completed)
            }
            "6" -> {
                binding.cellOrderHistory.tvOrderStatus.backgroundTintList = ColorStateList.valueOf(ResourcesCompat.getColor(resources, R.color.status1, null))
                binding.cellOrderHistory.tvOrderStatus.text = resources.getString(R.string.cancelled)
            }
            "7" -> {
                binding.cellOrderHistory.tvOrderStatus.backgroundTintList = ColorStateList.valueOf(ResourcesCompat.getColor(resources, R.color.status1, null))
                binding.cellOrderHistory.tvOrderStatus.text = resources.getString(R.string.cancelled)
            }

        }
    }

    private fun callApiOrderDetail() {
        showLoadingProgress(this@OrderDetailActivity)
        val map = HashMap<String, String>()
        map["order_id"] = intent.getStringExtra("order_id")?:""
        Log.e("order_id",intent.getStringExtra("order_id")?:"")
        val call = ApiClient.getClient.setGetOrderDetail(map)
        call.enqueue(object : Callback<OrderDetailData> {
            override fun onResponse(
                call: Call<OrderDetailData>,
                response: Response<OrderDetailData>
            ) {
                if (response.code() == 200) {
                    Common.dismissLoadingProgress()
                    val restResponse: OrderDetailData = response.body()!!
                    if (restResponse.status==1) {
                        if ((restResponse.data?.size ?: 0) > 0) {
                            binding.rvOrderItemFood.visibility = View.VISIBLE
                            setFoodDetailData(restResponse)
                        } else {
                            binding.rvOrderItemFood.visibility = View.GONE
                        }
                        binding.fmOrderDetail.visibility=View.VISIBLE
                    } else if (restResponse.status==0) {
                        Common.dismissLoadingProgress()
                        binding.rvOrderItemFood.visibility = View.GONE
                    }
                }
            }

            override fun onFailure(call: Call<OrderDetailData>, t: Throwable) {
                Common.dismissLoadingProgress()
                Common.alertErrorOrValidationDialog(
                    this@OrderDetailActivity,
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }

    @SuppressLint("SetTextI18n")
    private fun setFoodDetailData(response: OrderDetailData) {
        if (response.data!!.size > 0) {
            setFoodCategoryAdaptor(response.data)
        }
        orderInfo(response)

        if (response.summery?.offerCode == null) {
            binding.rlDiscount.visibility = View.GONE




            binding.tvOrderTotalPrice.text =Common.getPrice(currencyPos,currency,response.summery?.orderTotal.toString())

            binding.tvOrderTaxPrice.text =Common.getPrice(currencyPos,currency,response.summery?.tax.toString())

            binding.tvOrderDeliveryCharge.text =Common.getPrice(currencyPos,currency, response.summery!!.deliveryCharge.toString())


            val getTex: Float = (response.summery.orderTotal!!.toFloat() * response.summery.tax!!.toFloat()) / 100.toFloat()
            binding.tvTitleTex.text = "Tax (${response.summery.tax}%)"
            binding.tvOrderTaxPrice.text =Common.getPrice(currencyPos,currency,getTex.toString())

            val totalPrice = response.summery.orderTotal.toFloat() + getTex + response.summery.deliveryCharge!!.toFloat()
            binding.tvOrderTotalCharge.text =Common.getPrice(currencyPos,currency,totalPrice.toString())

        } else {
            binding.rlDiscount.visibility = View.VISIBLE
            binding.tvOrderTotalPrice.text =Common.getPrice(currencyPos,currency,response.summery.orderTotal.toString())

            binding.tvOrderTaxPrice.text =Common.getPrice(currencyPos,currency,response.summery.tax.toString())

            binding.tvOrderDeliveryCharge.text =Common.getPrice(currencyPos,currency,response.summery.deliveryCharge.toString())


            val getTex: Float =
                (response.summery.orderTotal!!.toFloat() * response.summery.tax!!.toFloat()) / 100
            binding.tvTitleTex.text = "Tax (${response.summery.tax}%)"
            binding.tvOrderTaxPrice.text =Common.getPrice(currencyPos,currency,getTex.toString())


            binding.tvDiscountOffer.text = Common.getPrice(currencyPos,currency,response.summery.discountAmount.toString())


            binding.tvPromocode.text = response.summery.offerCode
            val subtotal =
                response.summery.orderTotal.toFloat() - response.summery.discountAmount?.toFloat()!!
            val totalprice =
                subtotal + getTex + response.summery.deliveryCharge!!.toFloat()
            binding.tvOrderTotalCharge.text =Common.getPrice(currencyPos,currency,totalprice.toString())

        }

        Glide.with(this@OrderDetailActivity).load(response.userInfo?.profileImage).transition (
            DrawableTransitionOptions.withCrossFade(500))
            .placeholder(ResourcesCompat.getDrawable(resources, R.drawable.ic_placeholder, null))
            .into(binding.ivUserDetail)
        binding.tvUserName.text = response.userInfo?.name.toString()
        binding.tvOrderAddress.text =  response.summery.address.toString()
            .plus(", ${response.summery.houseNo.toString()}")
            .plus(", ${response.summery.area.toString()}")


//        binding.tvUserAddress.text = response.getDelivery_address()
//        binding. tvUserLandMark.text = response.getLandmark()
//        binding.tvUserBuilding.text = response.getBuilding()
            binding.btnCall.setOnClickListener {
                if (response.userInfo?.mobile != null) {
                    val call: Uri = Uri.parse("tel:${response.userInfo.mobile}")
                    val surf = Intent(Intent.ACTION_DIAL, call)
                    startActivity(surf)
                }
            }

        binding. btnMap.setOnClickListener {
            if (response.summery.lang != null && response.summery.lat != null) {
                val urlAddress =
                    "http://maps.google.com/maps?q=" + response.summery.lat + "," + response.summery.lang + "(" + "FoodApp" + ")&iwloc=A&hl=es"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(urlAddress))
                startActivity(intent)
            }
        }

        if (intent.getStringExtra("status").equals("3")) {
            binding.tvDeliverd.visibility = View.VISIBLE
        } else {
            binding.tvDeliverd.visibility = View.GONE
        }

        binding.tvDeliverd.setOnClickListener {
            if (Common.isCheckNetwork(this@OrderDetailActivity)) {
                callApiOrderDeliver()
            } else {
                Common.alertErrorOrValidationDialog(
                    this@OrderDetailActivity,
                    resources.getString(R.string.no_internet)
                )
            }
        }
    }

    private fun setFoodCategoryAdaptor(orderHistoryList: ArrayList<OrderData>) {
        val orderHistoryAdapter =
            object : BaseAdaptor<OrderData>(this@OrderDetailActivity, orderHistoryList) {
                @SuppressLint("SetTextI18n", "NewApi")
                override fun onBindData(
                    holder: RecyclerView.ViewHolder?,
                    `val`: OrderData,
                    position: Int
                ) {
                    val tvOrderFoodName: TextView = holder!!.itemView.findViewById(R.id.tvFoodName)
                    val tvPrice: TextView = holder.itemView.findViewById(R.id.tvPrice)
                    val tvQtyNumber: TextView = holder.itemView.findViewById(R.id.tvQty)
                    val tvAddons: TextView = holder.itemView.findViewById(R.id.tvAddons)
                    val tvVariation: TextView = holder.itemView.findViewById(R.id.tvVariation)
                    val ivVeg: AppCompatImageView = holder.itemView.findViewById(R.id.ivVeg)
                    val ivFoodCart: AppCompatImageView = holder.itemView.findViewById(R.id.ivFoodCart)


                    if (`val`.itemType == "2") {
                        ivVeg.setImageResource(R.drawable.ic_nonveg)
                    } else {
                        ivVeg.setImageResource(R.drawable.ic_vegetarian)
                    }

                    tvOrderFoodName.text = orderHistoryList[position].itemName
//                    tvAddons.text = orderHistoryList[position].addonsName
//                    tvPrice.text = Common.getPrice(currencyPos,currency,orderHistoryList[position].totalPrice.toString())

                    tvQtyNumber.text = "QTY : ${orderHistoryList[position].qty}"

                    val itemPrice=orderHistoryList[position].itemPrice?.toDouble()?.plus(orderHistoryList[position].addonsTotalPrice?.toDouble()?:0.00)

                    tvPrice.text = Common.getPrice(currencyPos, currency, itemPrice.toString() ?: "0.00")


                    if(orderHistoryList[position].variation?.isEmpty() == true ||orderHistoryList[position].variation=="null")
                    {
                        tvVariation.text="-"
                    }else
                    {
                        tvVariation.text = orderHistoryList[position].variation

                    }

                    if(orderHistoryList[position].addonsName?.isEmpty() == true ||orderHistoryList[position].addonsName=="null")
                    {
                        tvAddons.text="-"
                        tvAddons.isEnabled=false
                        tvAddons.isClickable=false
                    }else
                    {
                        tvAddons.text="Add-ons>>"
                        tvAddons.isEnabled=true
                        tvAddons.isClickable=true
                    }

                    tvAddons.setOnClickListener {
                        val fragAddOns= FragAddons()
                        val bundle= Bundle()
                        bundle.putString("addOnsName",orderHistoryList[position].addonsName)
                        bundle.putString("addOnsPrice",orderHistoryList[position].addonsPrice)
                        fragAddOns.arguments=bundle
                        fragAddOns.show(supportFragmentManager,FragAddons::class.java.name)

                    }

                    Glide.with(this@OrderDetailActivity).load(orderHistoryList[position].itemImage)
                        .transition(DrawableTransitionOptions.withCrossFade(500))
                        .into(ivFoodCart)




                }

                override fun setItemLayout(): Int {
                    return R.layout.cell_order_summery_item
                }

                override fun setNoDataView(): TextView? {
                    return null
                }
            }
        binding.rvOrderItemFood.adapter = orderHistoryAdapter
        binding.rvOrderItemFood.layoutManager = LinearLayoutManager(this@OrderDetailActivity)
        binding.rvOrderItemFood.itemAnimator = DefaultItemAnimator()
        binding.rvOrderItemFood.isNestedScrollingEnabled = true
    }

    private fun callApiOrderDeliver() {
        showLoadingProgress(this@OrderDetailActivity)
        val map = HashMap<String, String>()
        map["order_id"] = intent.getStringExtra("order_id")!!
        val call = ApiClient.getClient.setOrderDeliver(map)
        call.enqueue(object : Callback<SingleResponse> {
            override fun onResponse(
                call: Call<SingleResponse>,
                response: Response<SingleResponse>
            ) {
                if (response.code() == 200) {
                    Common.dismissLoadingProgress()
                    val restResponse: SingleResponse = response.body()!!
                    if (restResponse.status==1) {
                        successfulDialog(this@OrderDetailActivity, restResponse.message.toString())
                    } else if (restResponse.status==0) {
                        Common.dismissLoadingProgress()
                        binding.rvOrderItemFood.visibility = View.GONE
                    }
                }
            }

            override fun onFailure(call: Call<SingleResponse>, t: Throwable) {
                Common.dismissLoadingProgress()
                Common.alertErrorOrValidationDialog(
                    this@OrderDetailActivity,
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }

    fun successfulDialog(act: Activity, msg: String?) {
        var dialog: Dialog? = null
        try {
            dialog?.dismiss()
            dialog = Dialog(act, R.style.AppCompatAlertDialogStyleBig)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT
            )
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCancelable(false)
            val mInflater = LayoutInflater.from(act)
            val mView = mInflater.inflate(R.layout.dlg_validation, null, false)
            val textDesc: TextView = mView.findViewById(R.id.tvMessage)
            textDesc.text = msg
            val tvOk: TextView = mView.findViewById(R.id.tvOk)
            val finalDialog: Dialog = dialog
            tvOk.setOnClickListener {
                finalDialog.dismiss()
                startActivity(
                    Intent(
                        this@OrderDetailActivity,
                        DashboardActivity::class.java
                    ).putExtra("pos", "2")
                )
                finish()
                finishAffinity()
            }
            dialog.setContentView(mView)
            dialog.show()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(this@OrderDetailActivity, false)
    }
}