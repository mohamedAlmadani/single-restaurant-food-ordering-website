package com.singlerestaurant.driver.activity

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import com.singlerestaurant.driver.R
import com.singlerestaurant.driver.base.BaseActivity
import com.singlerestaurant.driver.utils.Common
import com.singlerestaurant.driver.api.*
import com.singlerestaurant.driver.databinding.ActForgetpasswordBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.HashMap

class ForgetPasswordActivity : BaseActivity() {
    private lateinit var binding:ActForgetpasswordBinding

    override fun setLayout()=binding.root
    override fun initView() {
        binding= ActForgetpasswordBinding.inflate(layoutInflater)
        Common.getCurrentLanguage(this@ForgetPasswordActivity, false)
    }

    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(this@ForgetPasswordActivity, false)
    }

    fun onClick(v: View?) {
        when (v!!.id) {
            R.id.ivBack -> {
                finish()
            }
            R.id.tvSubmit -> {
                if(ApiClient.System_environment==Common.SendBox)
                {
                    Common.alertErrorOrValidationDialog(this@ForgetPasswordActivity, resources.getString(R.string.send_box_error_alert))

                }else {


                    if (binding.edEmail.text.toString() == "") {
                        Common.alertErrorOrValidationDialog(
                            this@ForgetPasswordActivity,
                            resources.getString(R.string.validation_all)
                        )
                    } else if (!Common.isValidEmail(binding.edEmail.text.toString())) {
                        Common.alertErrorOrValidationDialog(
                            this@ForgetPasswordActivity,
                            resources.getString(R.string.validation_valid_email)
                        )
                    } else {
                        val hasmap = HashMap<String, String>()
                        hasmap["email"] = binding.edEmail.text.toString()
                        if (Common.isCheckNetwork(this@ForgetPasswordActivity)) {
                            callApiForgotPassword(hasmap)
                        } else {
                            Common.alertErrorOrValidationDialog(
                                this@ForgetPasswordActivity,
                                resources.getString(R.string.no_internet)
                            )
                        }
                    }
                }
            }
        }
    }

    private fun callApiForgotPassword(hasmap: HashMap<String, String>) {
        Common.showLoadingProgress(this@ForgetPasswordActivity)
        val call = ApiClient.getClient.setForgotPassword(hasmap)
        call.enqueue(object : Callback<SingleResponse> {
            override fun onResponse(call: Call<SingleResponse>, response: Response<SingleResponse>) {
                if (response.code() == 201) {
                    val restResponse: SingleResponse = response.body()!!
                    if (restResponse.status==1) {
                        Common.dismissLoadingProgress()
                        successfulDialog(this@ForgetPasswordActivity,
                                restResponse.message.toString()
                        )
                    }
                } else {
                    Common.dismissLoadingProgress()
                    Common.alertErrorOrValidationDialog(
                            this@ForgetPasswordActivity,
                            resources.getString(R.string.error_msg)
                    )
                }
            }

            override fun onFailure(call: Call<SingleResponse>, t: Throwable) {
                Common.dismissLoadingProgress()
                Common.alertErrorOrValidationDialog(
                        this@ForgetPasswordActivity,
                        resources.getString(R.string.error_msg)
                )
            }
        })
    }

    fun successfulDialog(act: Activity, msg: String?) {
        var dialog: Dialog? = null
        try {
            dialog?.dismiss()
            dialog = Dialog(act, R.style.AppCompatAlertDialogStyleBig)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setLayout(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT
            );
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCancelable(false)
            val mInflater= LayoutInflater.from(act)
            val mView = mInflater.inflate(R.layout.dlg_validation, null, false)
            val textDesc: TextView = mView.findViewById(R.id.tvMessage)
            textDesc.text = msg
            val tvOk: TextView = mView.findViewById(R.id.tvOk)
            val finalDialog: Dialog = dialog
            tvOk.setOnClickListener {
                finalDialog.dismiss()
                finish()
            }
            dialog.setContentView(mView)
            dialog.show()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }
}