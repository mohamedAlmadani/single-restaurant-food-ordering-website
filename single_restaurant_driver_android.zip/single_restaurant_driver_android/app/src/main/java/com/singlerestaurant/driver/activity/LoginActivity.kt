package com.singlerestaurant.driver.activity

import android.content.Intent
import android.view.View
import com.singlerestaurant.driver.R
import com.singlerestaurant.driver.api.ApiClient
import com.singlerestaurant.driver.base.BaseActivity
import com.singlerestaurant.driver.databinding.ActLoginBinding
import com.singlerestaurant.driver.model.LoginModel
import com.singlerestaurant.driver.model.LoginResponse
import com.singlerestaurant.driver.utils.Common
import com.singlerestaurant.driver.utils.Common.getLog
import com.singlerestaurant.driver.utils.Common.showLoadingProgress
import com.singlerestaurant.driver.utils.SharePreference
import com.singlerestaurant.driver.utils.SharePreference.Companion.setStringPref
import com.singlerestaurant.driver.utils.SharePreference.Companion.userEmail
import com.singlerestaurant.driver.utils.SharePreference.Companion.userId
import com.singlerestaurant.driver.utils.SharePreference.Companion.userMobile
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class LoginActivity : BaseActivity() {
    private lateinit var binding:ActLoginBinding
    var strToken = ""
    override fun setLayout()=binding.root

    override fun initView() {
        binding= ActLoginBinding.inflate(layoutInflater)
        Common.getCurrentLanguage(this@LoginActivity, false)
        FirebaseApp.initializeApp(this@LoginActivity)
        FirebaseMessaging.getInstance().token.addOnCompleteListener {
            strToken = it.result
        }

        if(ApiClient.System_environment==Common.SendBox)
        {
            binding.edEmail.setText("driver@gmail.com")
            binding.edPassword.setText("123456")
        }

        getLog("Token== ", strToken)
        getLog(
                "Lang ", SharePreference.getStringPref(
                this@LoginActivity,
                SharePreference.SELECTED_LANGUAGE
        )!!
        )
    }

    fun onClick(v: View?) {
        when (v!!.id) {
            R.id.tvLogin -> {
                if (binding.edEmail.text.toString() == "") {
                    Common.alertErrorOrValidationDialog(
                            this@LoginActivity,
                            resources.getString(R.string.validation_all)
                    )
                } else if (!Common.isValidEmail(binding.edEmail.text.toString())) {
                    Common.alertErrorOrValidationDialog(
                            this@LoginActivity,
                            resources.getString(R.string.validation_valid_email)
                    )
                } else if (binding.edPassword.text.toString() == "") {
                    Common.alertErrorOrValidationDialog(
                            this@LoginActivity,
                            resources.getString(R.string.validation_all)
                    )
                } else {
                    val request = HashMap<String, String>()
                    request["email"] = binding.edEmail.text.toString()
                    request["password"] = binding.edPassword.text.toString()
                    request["token"] = strToken
                    if (Common.isCheckNetwork(this@LoginActivity)) {
                        callApiLogin(request)
                    } else {
                        Common.alertErrorOrValidationDialog(
                                this@LoginActivity,
                                resources.getString(R.string.no_internet)
                        )
                    }
                }
            }
            R.id.tvForgetPassword -> {
                openActivity(ForgetPasswordActivity::class.java)
            }
        }
    }

    private fun callApiLogin(hasmap: HashMap<String, String>) {
        showLoadingProgress(this@LoginActivity)
        val call = ApiClient.getClient.getLogin(hasmap)
        call.enqueue(object : Callback<LoginResponse> {
            override fun onResponse(
                    call: Call<LoginResponse>,
                    response: Response<LoginResponse>
            ) {
                if (response.code() == 200) {
                    Common.dismissLoadingProgress()

                    val loginResponse: LoginResponse = response.body()!!
                    if (loginResponse.status==1) {
                        val loginModel: LoginModel = loginResponse.data!!
                        SharePreference.setBooleanPref(
                                this@LoginActivity,
                                SharePreference.isLogin,
                                true
                        )
                        setStringPref(this@LoginActivity, userId, loginModel.id.toString())
                        setStringPref(this@LoginActivity, userMobile, loginModel.mobile.toString())
                        setStringPref(this@LoginActivity, userEmail, loginModel.email.toString())
                        val intent = Intent(this@LoginActivity, DashboardActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        finish()
                        finishAffinity()
                    }else
                    {
                        Common.alertErrorOrValidationDialog(
                            this@LoginActivity,
                          loginResponse.message.toString()
                        )
                    }
                } else {
                    val error = JSONObject(response.errorBody()!!.string())
                    Common.dismissLoadingProgress()
                    Common.alertErrorOrValidationDialog(
                            this@LoginActivity,
                            error.getString("message")
                    )
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                Common.dismissLoadingProgress()
                Common.alertErrorOrValidationDialog(
                        this@LoginActivity,
                        resources.getString(R.string.error_msg)
                )
            }
        })
    }

    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(this@LoginActivity, false)
    }


}