package com.singlerestaurant.driver.fragment

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.singlerestaurant.driver.R
import com.singlerestaurant.driver.activity.OrderDetailActivity
import com.singlerestaurant.driver.api.ApiClient
import com.singlerestaurant.driver.base.BaseAdaptor
import com.singlerestaurant.driver.databinding.FragOrderhistoryBinding
import com.singlerestaurant.driver.model.OrderHistoryModel
import com.singlerestaurant.driver.model.OrderHistoryResponse
import com.singlerestaurant.driver.utils.Common
import com.singlerestaurant.driver.utils.Common.alertErrorOrValidationDialog
import com.singlerestaurant.driver.utils.Common.dismissLoadingProgress
import com.singlerestaurant.driver.utils.Common.showLoadingProgress
import com.singlerestaurant.driver.utils.SharePreference
import com.singlerestaurant.driver.utils.SharePreference.Companion.getStringPref

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class OrderHistoryFragment : Fragment() {

    private lateinit var binding: FragOrderhistoryBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragOrderhistoryBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Common.getCurrentLanguage(requireActivity(), false)
        if (Common.isCheckNetwork(requireActivity())) {
            callApiOrderHistory()
        } else {
            alertErrorOrValidationDialog(
                requireActivity(),
                resources.getString(R.string.no_internet)
            )
        }



        binding.swipeRefresh.setOnRefreshListener { // Your code to refresh the list here.
            if (Common.isCheckNetwork(requireActivity())) {
                binding.swipeRefresh.isRefreshing = false
                callApiOrderHistory()
            } else {
                alertErrorOrValidationDialog(
                    requireActivity(),
                    resources.getString(R.string.no_internet)
                )
            }
        }
    }


    private fun callApiOrderHistory() {
        showLoadingProgress(requireActivity())
        val map = HashMap<String, String>()
        map["driver_id"] = getStringPref(requireActivity(), SharePreference.userId)!!
        val call = ApiClient.getClient.getOrderHistory(map)
        call.enqueue(object : Callback<OrderHistoryResponse> {
            override fun onResponse(
                call: Call<OrderHistoryResponse>,
                response: Response<OrderHistoryResponse>
            ) {
                if (response.code() == 200) {
                    binding.linearHistory.visibility=View.VISIBLE
                    dismissLoadingProgress()
                    val restResponse: OrderHistoryResponse = response.body()!!
                    if (restResponse.status==1) {
                        if ((restResponse.data?.size ?: 0) > 0) {
                            if (isAdded) {
                                binding.rvOrderHistory.visibility = View.VISIBLE
                                binding.tvNoDataFound.visibility = View.GONE
                            }
                            val foodCategoryList = restResponse.data
                            foodCategoryList?.let { setFoodCategoryAdaptor(it) }
                        } else {
                            binding.rvOrderHistory.visibility = View.GONE
                            binding.tvNoDataFound.visibility = View.VISIBLE
                        }

                    } else if (restResponse.status==0) {
                        dismissLoadingProgress()
                        binding.rvOrderHistory.visibility = View.GONE
                        binding.tvNoDataFound.visibility = View.VISIBLE
                    }
                }
            }

            override fun onFailure(call: Call<OrderHistoryResponse>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(
                    activity!!,
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }


    fun setFoodCategoryAdaptor(
        orderHistoryList: ArrayList<OrderHistoryModel>
    ) {
        val orderHistoryAdapter =
            object : BaseAdaptor<OrderHistoryModel>(requireActivity(), orderHistoryList) {
                @SuppressLint("SetTextI18n", "NewApi")
                override fun onBindData(
                    holder: RecyclerView.ViewHolder?,
                    `val`: OrderHistoryModel,
                    position: Int
                ) {

                    val tvOrderNumber: TextView = holder!!.itemView.findViewById(R.id.tvOrderNumber)
                    val tvPrice: TextView = holder.itemView.findViewById(R.id.tvPrice)
                    val tvOrderStatus: TextView = holder.itemView.findViewById(R.id.tvOrderStatus)
                    val tvPaymentType: TextView = holder.itemView.findViewById(R.id.tvPaymentType)
                    val tvOrderDate: TextView = holder.itemView.findViewById(R.id.tvOrderDate)

                    tvOrderNumber.text = "#${orderHistoryList[position].orderNumber.toString()}"

                    val currency= getStringPref(requireActivity(),SharePreference.isCurrancy) ?:""
                    val currencyPos= getStringPref(requireActivity(),SharePreference.currencyPos) ?:""
                    tvPrice.text = Common.getPrice(currencyPos,currency,orderHistoryList[position].grandTotal.toString())


                    tvOrderDate.text =
                        orderHistoryList[position].date?.let { Common.getDate(it) }

                    when (orderHistoryList[position].status) {
                        "6" -> {
                            tvOrderStatus.backgroundTintList = ColorStateList.valueOf(
                                ResourcesCompat.getColor(
                                    resources,
                                    R.color.status1,
                                    null
                                )
                            )
                            tvOrderStatus.text = resources.getString(R.string.cancelled)
                        }
                        "7" -> {
                            tvOrderStatus.backgroundTintList = ColorStateList.valueOf(
                                ResourcesCompat.getColor(
                                    resources,
                                    R.color.status1,
                                    null
                                )
                            )
                            tvOrderStatus.text = resources.getString(R.string.cancelled)
                        }
                        "4" -> {
                            tvOrderStatus.backgroundTintList = ColorStateList.valueOf(
                                ResourcesCompat.getColor(
                                    resources,
                                    R.color.blue,
                                    null
                                )
                            )
                            tvOrderStatus.text = resources.getString(R.string.on_the_way)
                        }
                        "5"->{
                            tvOrderStatus.backgroundTintList = ColorStateList.valueOf(
                                ResourcesCompat.getColor(
                                    resources,
                                    R.color.light_green,
                                    null
                                )
                            )
                            tvOrderStatus.text = resources.getString(R.string.completed)
                        }
                    }

                    when {
                        orderHistoryList[position].transactionType!!.toInt() == 1 -> {
                            tvPaymentType.text = resources.getString(R.string.payment_type_)
                                .plus("  ${resources.getString(R.string.cash)}")
                        }
                        orderHistoryList[position].transactionType!!.toInt() == 3 -> {
                            tvPaymentType.text = resources.getString(R.string.payment_type_)
                                .plus("  ${resources.getString(R.string.razorpay)}")
                        }
                        orderHistoryList[position].transactionType!!.toInt() == 4 -> {
                            tvPaymentType.text = resources.getString(R.string.payment_type_)
                                .plus("  ${resources.getString(R.string.stripe)}")
                        }
                        orderHistoryList[position].transactionType!!.toInt() == 5 -> {
                            tvPaymentType.text = resources.getString(R.string.payment_type_)
                                .plus("  ${resources.getString(R.string.flutter_wave)}")
                        }
                        orderHistoryList[position].transactionType!!.toInt() == 6 -> {
                            tvPaymentType.text = resources.getString(R.string.payment_type_)
                                .plus("  ${resources.getString(R.string.paystack)}")
                        }
                        else -> {
                            tvPaymentType.text = resources.getString(R.string.payment_type_)
                                .plus("  ${resources.getString(R.string.wallet)}")
                        }
                    }







                    holder.itemView.setOnClickListener {
                        startActivity(
                            Intent(requireActivity(), OrderDetailActivity::class.java).putExtra(
                                "order_id",
                                orderHistoryList[position].id.toString()
                            ).putExtra(
                                "status",
                                orderHistoryList[position].status.toString()
                            ).putExtra(
                                "paymentType",
                                orderHistoryList[position].transactionType
                            ).putExtra("orderDate", orderHistoryList[position].date.toString()).putExtra(
                                "order_number",
                                orderHistoryList[position].orderNumber.toString()
                            )
                        )
                    }

                }

                override fun setItemLayout(): Int {
                    return R.layout.cell_order_history
                }

                override fun setNoDataView(): TextView? {
                    return null
                }
            }
        binding.rvOrderHistory.adapter = orderHistoryAdapter
        binding.rvOrderHistory.layoutManager = LinearLayoutManager(requireActivity())
        binding.rvOrderHistory.itemAnimator = DefaultItemAnimator()
        binding.rvOrderHistory.isNestedScrollingEnabled = true
    }

    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(requireActivity(), false)
    }
}