package com.singlerestaurant.driver.api

import com.singlerestaurant.driver.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ApiInterface {
    @POST("driverlogin")
    fun getLogin(@Body map: HashMap<String, String>): Call<LoginResponse>

    @POST("drivergetprofile")
    fun getProfile(@Body map: HashMap<String, String>): Call<GetProfileResponse>

    @Multipart
    @POST("drivereditprofile")
    fun setProfile(@Part("driver_id") userId: RequestBody,@Part("name") name: RequestBody, @Part profileimage: MultipartBody.Part?): Call<SingleResponse>

    @POST("driverchangepassword")
    fun setChangePassword(@Body map: HashMap<String, String>):Call<SingleResponse>

    @POST("driverforgotPassword")
    fun setForgotPassword(@Body map: HashMap<String, String>):Call<SingleResponse>

    @POST("driverorder")
    fun getOrderHistory(@Body map: HashMap<String, String>):Call<OrderHistoryResponse>

    @POST("getorderdetails")
    fun setGetOrderDetail(@Body map: HashMap<String, String>):Call<OrderDetailData>

    @POST("delivered")
    fun setOrderDeliver(@Body map: HashMap<String, String>):Call<SingleResponse>


    @POST("driverongoingorder")
    fun setOnGoingOrder(@Body map: HashMap<String, String>):Call<OrderHistoryResponse>

    @GET("cmspages")
    fun cmsPages(): Call<CmsPagesResponse>
}