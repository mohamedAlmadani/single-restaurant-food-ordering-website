package com.singlerestaurant.driver.activity

import android.annotation.SuppressLint
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Window
import android.view.WindowManager
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.singlerestaurant.driver.R
import com.singlerestaurant.driver.base.BaseActivity
import com.singlerestaurant.driver.databinding.ActDashboardBinding
import com.singlerestaurant.driver.databinding.DlgConfomationBinding
import com.singlerestaurant.driver.databinding.DlgLogoutBinding
import com.singlerestaurant.driver.fragment.HomeFragment
import com.singlerestaurant.driver.fragment.OrderHistoryFragment
import com.singlerestaurant.driver.fragment.SettingFragment
import com.singlerestaurant.driver.utils.Common

class DashboardActivity : BaseActivity() {


    private lateinit var binding:ActDashboardBinding
    override fun setLayout()=binding.root

    override fun initView() {
        binding= ActDashboardBinding.inflate(layoutInflater)
        Common.getCurrentLanguage(this@DashboardActivity, false)


        if (intent.getStringExtra("pos") != null) {
            setFragment(intent.getStringExtra("pos")?.toInt()?:0)
        } else {
            setFragment(1)
        }

        bottomSheetItemNavigation()


    }



    override fun onBackPressed() {
        mExitDialog()
    }


    private fun bottomSheetItemNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            val fragment = supportFragmentManager.findFragmentById(R.id.mainContainer)
            when (item.itemId) {
                R.id.ivHome -> {
                    if (fragment !is HomeFragment) {
                        supportFragmentManager.fragments.clear()
                        Common.replaceFragment(
                            supportFragmentManager,
                            HomeFragment(),
                            R.id.mainContainer
                        )
                    }
                    true
                }
                R.id.ivBooking -> {
                    if (fragment !is OrderHistoryFragment) {
                        supportFragmentManager.fragments.clear()
                        Common.replaceFragment(
                            supportFragmentManager,
                            OrderHistoryFragment(),
                            R.id.mainContainer
                        )
                    }
                    true
                }

                R.id.ivProfile -> {
                    if (fragment !is SettingFragment) {
                        supportFragmentManager.fragments.clear()
                        Common.replaceFragment(
                            supportFragmentManager,
                            SettingFragment(),
                            R.id.mainContainer
                        )
                    }

                    true
                }

                else -> {
                    false
                }
            }
        }
    }


    @SuppressLint("WrongConstant")
    fun replaceFragment(fragment: Fragment) {
        val fragmentManager: FragmentManager = supportFragmentManager
        val fragmentTransaction: FragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.mainContainer, fragment)
        fragmentTransaction.addToBackStack(fragment.toString())
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_ENTER_MASK)
        fragmentTransaction.commit()
    }






    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(this@DashboardActivity, false)
    }

    private fun setFragment(pos: Int) {
        when (pos) {
            1 -> {
                replaceFragment(HomeFragment())
            }
            2 -> {
                replaceFragment(OrderHistoryFragment())
            }
            3 -> {
                replaceFragment(SettingFragment())
            }
            4 -> {
                alertLogOutDialog()
            }
        }
    }

    private fun alertLogOutDialog() {
        var dialog: Dialog? = null
        try {
            dialog?.dismiss()
            dialog = Dialog(this@DashboardActivity, R.style.AppCompatAlertDialogStyleBig)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setLayout(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT
            )
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCancelable(false)
            val mView = DlgLogoutBinding.inflate(layoutInflater)

            val finalDialog: Dialog = dialog
            mView.tvLogout.setOnClickListener {
                finalDialog.dismiss()
                Common.setLogout(this@DashboardActivity)

            }
            mView.tvCancel.setOnClickListener {
                finalDialog.dismiss()
            }
            dialog.setContentView(mView.root)
            dialog.show()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    private fun mExitDialog() {
        var dialog: Dialog? = null
        try {
            dialog?.dismiss()
            dialog = Dialog(this@DashboardActivity, R.style.AppCompatAlertDialogStyleBig)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setLayout(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT
            )
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCancelable(false)
            val mView =DlgConfomationBinding.inflate(layoutInflater)

            val finalDialog: Dialog = dialog
            mView.tvYes.setOnClickListener {
                finalDialog.dismiss()
                ActivityCompat.finishAfterTransition(this@DashboardActivity)
                ActivityCompat.finishAffinity(this@DashboardActivity)
                finish()
            }
            mView.tvNo.setOnClickListener {
                finalDialog.dismiss()
            }
            dialog.setContentView(mView.root)
            dialog.show()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

}