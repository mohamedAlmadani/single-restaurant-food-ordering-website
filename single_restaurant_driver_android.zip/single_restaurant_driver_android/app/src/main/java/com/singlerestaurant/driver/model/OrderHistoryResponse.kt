package com.singlerestaurant.driver.model

import com.google.gson.annotations.SerializedName

data class OrderHistoryResponse(

	@field:SerializedName("data")
	val data: ArrayList<OrderHistoryModel>? = null,

	@field:SerializedName("ongoing_order")
	val ongoingOrder: Int? = null,

	@field:SerializedName("completed_order")
	val completedOrder: Int? = null,

	@field:SerializedName("message")
	val message: String? = null,

	@field:SerializedName("appdata")
	val appData: AppData? = null,

	@field:SerializedName("status")
	val status: Int? = null
)

data class OrderHistoryModel(

	@field:SerializedName("date")
	val date: String? = null,

	@field:SerializedName("order_number")
	val orderNumber: String? = null,

	@field:SerializedName("qty")
	val qty: String? = null,

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("grand_total")
	val grandTotal: String? = null,

	@field:SerializedName("transaction_type")
	val transactionType: String? = null,

	@field:SerializedName("status")
	val status: String? = null
)
