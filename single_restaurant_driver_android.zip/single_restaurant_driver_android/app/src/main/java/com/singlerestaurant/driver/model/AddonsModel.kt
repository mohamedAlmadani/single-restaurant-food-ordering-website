package com.singlerestaurant.driver.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName



data class AddonsModel(

    @field:SerializedName("id")
    val Id: Int? = null,

    @field:SerializedName("name")
    val name: String? = null,

    @field:SerializedName("price")
    val price: String? = null,
    var isAddOnsSelect: Boolean = false
)
