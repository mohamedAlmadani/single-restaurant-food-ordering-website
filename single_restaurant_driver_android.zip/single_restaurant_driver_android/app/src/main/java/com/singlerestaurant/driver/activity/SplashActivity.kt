package com.singlerestaurant.driver.activity

import android.os.Handler
import android.os.Looper
import com.singlerestaurant.driver.R
import com.singlerestaurant.driver.base.BaseActivity
import com.singlerestaurant.driver.databinding.ActSplashBinding
import com.singlerestaurant.driver.utils.SharePreference
import com.singlerestaurant.driver.utils.SharePreference.Companion.getBooleanPref


class SplashActivity : BaseActivity() {

    private lateinit var binding:ActSplashBinding

    override fun setLayout()=binding.root

    override fun initView() {
        binding= ActSplashBinding.inflate(layoutInflater)

        Handler(Looper.getMainLooper()).postDelayed({
            if (getBooleanPref(this@SplashActivity, SharePreference.isLogin)) {
                openActivity(DashboardActivity::class.java)
                finish()
            } else {
                openActivity(LoginActivity::class.java)
                finish()
            }
        }, 3000)
    }
}