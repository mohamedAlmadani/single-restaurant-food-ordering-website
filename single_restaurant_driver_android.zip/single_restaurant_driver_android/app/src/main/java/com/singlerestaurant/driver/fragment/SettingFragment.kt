package com.singlerestaurant.driver.fragment

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.*
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.singlerestaurant.driver.R
import com.singlerestaurant.driver.activity.ActCmsPages
import com.singlerestaurant.driver.activity.ChangePasswordActivity
import com.singlerestaurant.driver.activity.EditProfileActivity
import com.singlerestaurant.driver.api.ApiClient
import com.singlerestaurant.driver.databinding.DlgLogoutBinding
import com.singlerestaurant.driver.databinding.FragSettingBinding
import com.singlerestaurant.driver.model.GetProfileResponse
import com.singlerestaurant.driver.model.ProfileModel
import com.singlerestaurant.driver.utils.Common
import com.singlerestaurant.driver.utils.Common.getCurrentLanguage
import com.singlerestaurant.driver.utils.SharePreference
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SettingFragment : Fragment() {
    private lateinit var binding: FragSettingBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragSettingBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        getCurrentLanguage(requireActivity(), false)

        initClickListeners()
        if (Common.isCheckNetwork(requireActivity())) {
            val request = HashMap<String, String>()
            request["user_id"] = SharePreference.getStringPref(
                requireActivity(),
                SharePreference.userId
            )!!
            callApiProfile()
        } else {
            Common.alertErrorOrValidationDialog(
                requireActivity(),
                resources.getString(R.string.no_internet)
            )
        }

    }

    private fun initClickListeners() {
        binding.editProfile.setOnClickListener {
            startActivity(Intent(requireActivity(), EditProfileActivity::class.java))
        }

        binding.linearChangePassword.setOnClickListener {
            startActivity(Intent(requireActivity(), ChangePasswordActivity::class.java))

        }


        binding.linearLogout.setOnClickListener {
            alertLogOutDialog()
        }

        binding.linearChangeLayout.setOnClickListener {
            val dialog = BottomSheetDialog(requireActivity())
            val mView = layoutInflater.inflate(R.layout.row_bottomsheetlayout, null)
            val btnLTREng = mView.findViewById<TextView>(R.id.tvLTR)
            val btnRTLHindi = mView.findViewById<TextView>(R.id.tvRTL)
            val btnCancel = mView.findViewById<TextView>(R.id.tvCancel)
            btnCancel.setOnClickListener {
                dialog.dismiss()
            }
            btnLTREng.setOnClickListener {
                SharePreference.setStringPref(
                    requireActivity(),
                    SharePreference.SELECTED_LANGUAGE,
                    requireActivity().resources.getString(R.string.language_english)
                )
                getCurrentLanguage(requireActivity(), true)
            }
            btnRTLHindi.setOnClickListener {
                SharePreference.setStringPref(
                    requireActivity(),
                    SharePreference.SELECTED_LANGUAGE,
                    requireActivity().resources.getString(R.string.language_hindi)
                )
                getCurrentLanguage(requireActivity(), true)
            }
            dialog.setCancelable(true)
            dialog.setContentView(mView)
            dialog.show()


        }


        binding.linearPrivacyPolicy.setOnClickListener {
            startActivity(
                Intent(activity, ActCmsPages::class.java).putExtra(
                    "title","privacypolicy")
            )
        }
        binding.linearAbout.setOnClickListener {
            startActivity(
                Intent(activity, ActCmsPages::class.java).putExtra(
                    "title","aboutUs")
            )
        }
    }


    private fun callApiProfile() {
        val request = HashMap<String, String>()
        request["driver_id"] = SharePreference.getStringPref(requireActivity(), SharePreference.userId) ?: ""
        Common.showLoadingProgress(requireActivity())
        val call = ApiClient.getClient.getProfile(request)
        call.enqueue(object : Callback<GetProfileResponse> {
            override fun onResponse(
                call: Call<GetProfileResponse>,
                response: Response<GetProfileResponse>
            ) {
                if (response.code() == 200) {
                    binding.clSettings.visibility=View.VISIBLE
                    val restResponse: GetProfileResponse = response.body()!!
                    if (restResponse.status==1) {
                        Common.dismissLoadingProgress()

                        val dataResponse = restResponse.data
                        SharePreference.setStringPref(
                            requireActivity(),
                            SharePreference.userName,
                            dataResponse?.name.toString()
                        )
                        SharePreference.setStringPref(
                            requireActivity(),
                            SharePreference.userProfile,
                            dataResponse?.profileImage.toString()
                        )
                        setProfileData(dataResponse)
                    } else if (restResponse.status==0) {
                        Common.dismissLoadingProgress()
                        Common.alertErrorOrValidationDialog(
                            requireActivity(),
                            restResponse.message
                        )
                    }
                } else {
                    val error = JSONObject(response.errorBody()!!.string())
                    if (error.getString("status").equals("2")) {
                        Common.dismissLoadingProgress()
                        Common.setLogout(requireActivity())
                    } else {
                        Common.dismissLoadingProgress()
                        Common.alertErrorOrValidationDialog(
                            requireActivity(),
                            error.getString("message")
                        )

                    }
                }
            }

            override fun onFailure(call: Call<GetProfileResponse>, t: Throwable) {
                Common.dismissLoadingProgress()
                Common.alertErrorOrValidationDialog(
                    requireActivity(),
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }

    private fun setProfileData(data: ProfileModel?) {
        Glide.with(requireActivity()).load(data?.profileImage.toString()).transition (
            DrawableTransitionOptions.withCrossFade(500))
            .placeholder(R.drawable.ic_placeholder).into(binding.ivProfile)

        binding.tvUserName.text=data?.name.toString()
        binding.tvEmail.text=data?.email.toString()
    }


    private fun alertLogOutDialog() {
        var dialog: Dialog? = null
        try {
            dialog?.dismiss()
            dialog = Dialog(requireActivity(), R.style.AppCompatAlertDialogStyleBig)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT
            )
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCancelable(false)
            val mInflater = LayoutInflater.from(requireActivity())
            val mView = DlgLogoutBinding.inflate(layoutInflater)

            val finalDialog: Dialog = dialog
            mView.tvLogout.setOnClickListener {
                finalDialog.dismiss()
                Common.setLogout(requireActivity())

            }
            mView.tvCancel.setOnClickListener {
                finalDialog.dismiss()
            }
            dialog.setContentView(mView.root)
            dialog.show()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }


    override fun onResume() {
        super.onResume()
        getCurrentLanguage(requireActivity(), false)
    }
}