package com.singlerestaurant.driver.model

import com.google.gson.annotations.SerializedName

data class OrderDetailResponse(
    @field:SerializedName("status")
    val status: Int? = null,
    @field:SerializedName("message")
    val message: String? = null,

    @field:SerializedName("data")
    val data: ArrayList<OrderData>? = null,

    @field:SerializedName("driver_info")
    val driverInfo: DriverInfo? = null,

    @field:SerializedName("user_info")
    val userInfo: UserInfo? = null,


    @field:SerializedName("summery")
    val summery: Summery? = null)



