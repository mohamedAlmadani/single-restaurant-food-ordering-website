package com.singlerestaurant.driver.activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.singlerestaurant.driver.R
import com.singlerestaurant.driver.api.ApiClient
import com.singlerestaurant.driver.databinding.ActCmsPagesBinding
import com.singlerestaurant.driver.model.CmsPagesResponse
import com.singlerestaurant.driver.model.GetProfileResponse
import com.singlerestaurant.driver.utils.Common
import com.singlerestaurant.driver.utils.SharePreference
import kotlinx.coroutines.launch
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ActCmsPages : AppCompatActivity() {
    private lateinit var binding: ActCmsPagesBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActCmsPagesBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.ivBack.setOnClickListener {
            finish()
        }

        if (SharePreference.getStringPref(
                this@ActCmsPages,
                SharePreference.SELECTED_LANGUAGE
            ).equals(resources.getString(R.string.language_hindi))) {

            binding.ivBack.rotation=180f
        }else{
            binding.ivBack.rotation=0f

        }

        binding.webView.webViewClient = WebViewClient()
        binding.webView.settings.loadsImagesAutomatically = true
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY

       if( intent.getStringExtra("title") == "privacypolicy"){
           callGetCmsPages()
       }else
       {
           binding.tvTitle.text = resources.getString(R.string.about_us)
           binding.webView.loadData(SharePreference.getStringPref(this@ActCmsPages, SharePreference.aboutUs).toString(), "text/html", "UTF-8")
       }

    }



    private fun callGetCmsPages() {
         Common.showLoadingProgress(this@ActCmsPages)
        val call = ApiClient.getClient.cmsPages()
        call.enqueue(object : Callback<CmsPagesResponse> {
            override fun onResponse(
                call: Call<CmsPagesResponse>,
                response: Response<CmsPagesResponse>
            ) {
                if (response.code() == 200) {
                    val restResponse: CmsPagesResponse = response.body()!!
                    if (restResponse.status==1) {
                        Common.dismissLoadingProgress()
                        val responseBody = response.body()
                        if (intent.getStringExtra("title") == "privacypolicy") {
                            binding.tvTitle.text = resources.getString(R.string.privacy_policy)
                            binding.webView.loadData(responseBody?.privacypolicy.toString(), "text/html", "UTF-8")
                        }

                    } else if (restResponse.status==0) {
                        Common.dismissLoadingProgress()
                        Common.alertErrorOrValidationDialog(
                            this@ActCmsPages,
                            restResponse.message
                        )
                    }
                } else {
                    val error = JSONObject(response.errorBody()!!.string())
                    if (error.getString("status").equals("2")) {
                        Common.dismissLoadingProgress()
                        Common.setLogout(this@ActCmsPages)
                    } else {
                        Common.dismissLoadingProgress()
                        Common.alertErrorOrValidationDialog(
                            this@ActCmsPages,
                            error.getString("message")
                        )

                    }
                }
            }

            override fun onFailure(call: Call<CmsPagesResponse>, t: Throwable) {
                Common.dismissLoadingProgress()
                Common.alertErrorOrValidationDialog(
                    this@ActCmsPages,
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }

}