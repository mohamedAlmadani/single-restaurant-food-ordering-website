package com.singlerestaurant.driver.activity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.singlerestaurant.driver.R
import com.singlerestaurant.driver.api.ApiClient
import com.singlerestaurant.driver.api.SingleResponse
import com.singlerestaurant.driver.base.BaseActivity
import com.singlerestaurant.driver.databinding.ActEditprofileBinding
import com.singlerestaurant.driver.model.GetProfileResponse
import com.singlerestaurant.driver.model.ProfileModel
import com.singlerestaurant.driver.utils.Common
import com.singlerestaurant.driver.utils.Common.alertErrorOrValidationDialog
import com.singlerestaurant.driver.utils.Common.dismissLoadingProgress
import com.singlerestaurant.driver.utils.Common.isCheckNetwork
import com.singlerestaurant.driver.utils.Common.isProfileEdit
import com.singlerestaurant.driver.utils.Common.isProfileMainEdit
import com.singlerestaurant.driver.utils.Common.setImageUpload
import com.singlerestaurant.driver.utils.Common.setRequestBody
import com.singlerestaurant.driver.utils.Common.showLoadingProgress
import com.singlerestaurant.driver.utils.SharePreference
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.github.dhaval2404.imagepicker.ImagePicker
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

@Suppress("DEPRECATION")
class EditProfileActivity : BaseActivity() {
    private val SELECT_FILE = 201
    private val REQUEST_CAMERA = 202
    private var mSelectedFileImg: File? = null
    private lateinit var binding: ActEditprofileBinding
    override fun setLayout() = binding.root

    override fun initView() {
        binding = ActEditprofileBinding.inflate(layoutInflater)
        if (isCheckNetwork(this@EditProfileActivity)) {
            callApiProfile()
        } else {
            alertErrorOrValidationDialog(
                this@EditProfileActivity,
                resources.getString(R.string.no_internet)
            )
        }

        if (SharePreference.getStringPref(
                this@EditProfileActivity,
                SharePreference.SELECTED_LANGUAGE
            ).equals(resources.getString(R.string.language_hindi))
        ) {
            binding.ivBack.rotation = 180F
        } else {
            binding.ivBack.rotation = 0F
        }
    }

    fun onClick(v: View?) {
        when (v!!.id) {
            R.id.ivBack -> {
                finish()
            }
            R.id.tvUpdate -> {
                if(ApiClient.System_environment==Common.SendBox)
                {
                    Common.alertErrorOrValidationDialog(this@EditProfileActivity, resources.getString(R.string.send_box_error_alert))

                }else {

                    if (binding.edUserName.text.toString() == "") {
                        alertErrorOrValidationDialog(
                            this@EditProfileActivity,
                            resources.getString(R.string.validation_all)
                        )
                    } else {
                        if (isCheckNetwork(this@EditProfileActivity)) {
                            mCallApiEditProfile()
                        } else {
                            alertErrorOrValidationDialog(
                                this@EditProfileActivity,
                                resources.getString(R.string.no_internet)
                            )
                        }
                    }
                }
            }
            R.id.ivGellary -> {
                getExternalStoragePermission()

            }

        }
    }

    private fun callApiProfile() {
        showLoadingProgress(this@EditProfileActivity)
        val request = HashMap<String, String>()

        request["driver_id"] =
            SharePreference.getStringPref(this@EditProfileActivity, SharePreference.userId)!!

        val call = ApiClient.getClient.getProfile(request)
        call.enqueue(object : Callback<GetProfileResponse> {
            override fun onResponse(
                call: Call<GetProfileResponse>,
                response: Response<GetProfileResponse>
            ) {
                if (response.code() == 200) {
                    val restResponse: GetProfileResponse = response.body()!!
                    if (restResponse.status == 1) {
                        dismissLoadingProgress()
                        val dataResponse = restResponse.data
                        setProfileData(dataResponse)
                        binding.profileLayout.visibility = View.VISIBLE
                    } else if (restResponse.status == 0) {
                        dismissLoadingProgress()
                        alertErrorOrValidationDialog(
                            this@EditProfileActivity,
                            restResponse.message.toString()
                        )
                    }
                }
            }

            override fun onFailure(call: Call<GetProfileResponse>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(
                    this@EditProfileActivity,
                    resources.getString(R.string.error_msg)
                )
            }
        })
    }

    private fun setProfileData(dataResponse: ProfileModel?) {
        binding.edEmailAddress.text = dataResponse?.email.toString()
        binding.edUserName.setText(dataResponse?.name.toString())
        binding.tvMobileNumber.text = dataResponse?.mobile.toString()
        Glide.with(this@EditProfileActivity).load(dataResponse?.profileImage.toString()).transition(DrawableTransitionOptions.withCrossFade(500))
            .placeholder(resources.getDrawable(R.drawable.ic_placeholder)).into(binding.ivProfile)

        SharePreference.setStringPref(
            this@EditProfileActivity,
            SharePreference.userName,
            dataResponse?.name.toString()
        )
        SharePreference.setStringPref(
            this@EditProfileActivity,
            SharePreference.userProfile,
            dataResponse?.profileImage.toString()
        )
        SharePreference.setStringPref(
            this@EditProfileActivity,
            SharePreference.userEmail,
            dataResponse?.email.toString()
        )
        SharePreference.setStringPref(
            this@EditProfileActivity,
            SharePreference.userMobile,
            dataResponse?.mobile.toString()
        )

    }


/*
    */
/*-------------Image Upload Code-------------*//*

    @SuppressLint("MissingSuperCall")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                onSelectFromGalleryResult(data)
            } else if (requestCode == REQUEST_CAMERA) {
                onCaptureImageResult(data!!)
            }
        }
    }
*/

    private fun getExternalStoragePermission() {
        Dexter.withActivity(this)
            .withPermissions(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                    if (report.areAllPermissionsGranted()) {
//                            imageSelectDialog(this@EditProfileActivity)

                        ImagePicker.with(this@EditProfileActivity)
                            .cropSquare()
                            .compress(1024)
                            .saveDir(
                                File(
                                    getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                                    resources.getString(R.string.app_name)
                                )
                            )
                            .maxResultSize(1080, 1080)
                            .createIntent { intent ->
                                startActivityForResult(intent, SELECT_FILE)
                            }
                    }
                    if (report.isAnyPermissionPermanentlyDenied) {
                        Common.settingDialog(this@EditProfileActivity)
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            })
            .onSameThread()
            .check()
    }


    @SuppressLint("MissingSuperCall")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                val fileUri = data?.data!!
                fileUri.path.let { mSelectedFileImg = File(it) }
                Glide.with(this@EditProfileActivity)
                    .load(fileUri.path).transition (DrawableTransitionOptions.withCrossFade(500))

                    .into(binding.ivProfile)
            } else if (requestCode == REQUEST_CAMERA) {
//                onCaptureImageResult(data!!)
            }
        } else if (resultCode == ImagePicker.RESULT_ERROR) {
            Toast.makeText(this@EditProfileActivity, ImagePicker.getError(data), Toast.LENGTH_SHORT)
                .show()
        }
    }


    private fun mCallApiEditProfile() {
        showLoadingProgress(this@EditProfileActivity)
        val call = if (mSelectedFileImg != null) {
            ApiClient.getClient.setProfile(
                setRequestBody(
                    SharePreference.getStringPref(
                        this@EditProfileActivity,
                        SharePreference.userId
                    )!!
                ),
                setRequestBody(binding.edUserName.text.toString()),
                setImageUpload("image", mSelectedFileImg!!)
            )
        } else {
            ApiClient.getClient.setProfile(
                setRequestBody(
                    SharePreference.getStringPref(
                        this@EditProfileActivity,
                        SharePreference.userId
                    )!!
                ), setRequestBody(binding.edUserName.text.toString()), null
            )
        }
        call.enqueue(object : Callback<SingleResponse> {
            override fun onResponse(
                call: Call<SingleResponse>,
                response: Response<SingleResponse>
            ) {
                if (response.code() == 200) {
                    val editProfileResponse: SingleResponse = response.body()!!
                    if (editProfileResponse.status == 1) {
                        dismissLoadingProgress()
                        isProfileEdit = true
                        isProfileMainEdit = true
                        successfulDialog(
                            this@EditProfileActivity,
                            editProfileResponse.message.toString()
                        )
                    } else if (editProfileResponse.status == 0) {
                        dismissLoadingProgress()
                        alertErrorOrValidationDialog(
                            this@EditProfileActivity,
                            editProfileResponse.message.toString()
                        )
                    }
                } else {
                    val restResponse = response.errorBody()!!.string()
                    val jsonObject = JSONObject(restResponse)
                    dismissLoadingProgress()
                    alertErrorOrValidationDialog(
                        this@EditProfileActivity,
                        jsonObject.getString("message")
                    )
                }

            }

            override fun onFailure(call: Call<SingleResponse>, t: Throwable) {
                dismissLoadingProgress()
                alertErrorOrValidationDialog(
                    this@EditProfileActivity,
                    resources.getString(R.string.error_msg)
                )
            }
        })

    }


    fun successfulDialog(act: Activity, msg: String?) {
        var dialog: Dialog? = null
        try {
            if (dialog != null) {
                dialog.dismiss()
                dialog = null
            }
            dialog = Dialog(act, R.style.AppCompatAlertDialogStyleBig)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.window!!.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT
            );
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCancelable(false)
            val mInflater = LayoutInflater.from(act)
            val mView = mInflater.inflate(R.layout.dlg_validation, null, false)
            val textDesc: TextView = mView.findViewById(R.id.tvMessage)
            textDesc.text = msg
            val tvOk: TextView = mView.findViewById(R.id.tvOk)
            val finalDialog: Dialog = dialog
            tvOk.setOnClickListener {
                finalDialog.dismiss()
                finish()
            }
            dialog.setContentView(mView)
            dialog.show()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(this@EditProfileActivity, false)
    }
}