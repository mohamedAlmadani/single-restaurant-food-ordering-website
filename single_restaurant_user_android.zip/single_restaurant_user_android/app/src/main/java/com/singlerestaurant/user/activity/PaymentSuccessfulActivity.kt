package com.singlerestaurant.user.activity

import android.content.Intent
import android.content.SharedPreferences
import android.view.View
import com.singlerestaurant.user.R
import com.singlerestaurant.user.base.BaseActivity
import com.singlerestaurant.user.databinding.ActivitySuccesspaymentBinding
import com.singlerestaurant.user.utils.Common
import com.singlerestaurant.user.utils.SharePreference

class PaymentSuccessfulActivity : BaseActivity() {
    private lateinit var binding:ActivitySuccesspaymentBinding
    override fun setLayout(): View = binding.root

    override fun InitView() {
        binding=ActivitySuccesspaymentBinding.inflate(layoutInflater)
        binding.tvProceed.setOnClickListener {
            if (Common.isLogin(this@PaymentSuccessfulActivity)) {
                startActivity(Intent(this@PaymentSuccessfulActivity,
                    OrderDetailActivity::class.java).putExtra("fromOrderSuccess", true)
                    .putExtra("order_id", intent.getStringExtra("order_id")))
                finish()
                finishAffinity()
            }else{
                SharePreference.setStringPref(this@PaymentSuccessfulActivity, SharePreference.guestaddress,"").toString()
                SharePreference.setStringPref(this@PaymentSuccessfulActivity, SharePreference.guesthouseno,"").toString()
                SharePreference.setStringPref(this@PaymentSuccessfulActivity, SharePreference.guestarea,"").toString()
                SharePreference.setStringPref(this@PaymentSuccessfulActivity, SharePreference.guestlat,"").toString()
                SharePreference.setStringPref(this@PaymentSuccessfulActivity, SharePreference.guestlong,"").toString()
                SharePreference.setStringPref(this@PaymentSuccessfulActivity, SharePreference.deliverycharge,"").toString()
                val intent =
                    Intent(this@PaymentSuccessfulActivity, DashboardActivity::class.java).putExtra("pos", "1")

                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                finish()

            }
        }
    }

    override fun onBackPressed() {
        return
    }
}