package com.singlerestaurant.user.activity

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.singlerestaurant.user.R
import com.singlerestaurant.user.api.ApiClient
import com.singlerestaurant.user.api.SingleResponsee
import com.singlerestaurant.user.databinding.ActToyyibpayBinding
import com.singlerestaurant.user.remote.NetworkResponse
import com.singlerestaurant.user.utils.Common
import com.singlerestaurant.user.utils.SharePreference
import kotlinx.coroutines.launch


class ActToyyibpay : AppCompatActivity() {
    private lateinit var binding:ActToyyibpayBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActToyyibpayBinding.inflate(layoutInflater)
        setContentView(binding.root)

       // binding.webView.webViewClient = WebViewClient()
        binding.webView.settings.loadsImagesAutomatically = true
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY

        var loadingFinished = true
        var redirect = false
        var uri = SharePreference.getStringPref(this@ActToyyibpay,SharePreference.toyyibpayurl).toString()
        var successuri = SharePreference.getStringPref(this@ActToyyibpay,SharePreference.toyyibsuccessurl).toString()
        Log.d("urll",uri )

        binding.webView.loadUrl(uri)
        binding.webView.webViewClient = object : WebViewClient() {
           /* override fun shouldOverrideUrlLoading(
                view: WebView,
                urlNewString: String,
            ): Boolean {
                if (!loadingFinished) {
                    redirect = true
                }
                loadingFinished = false
                binding.webView.loadUrl(uri)
                return true
            }*/

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                loadingFinished = false
                val successuri= SharePreference.getStringPref(this@ActToyyibpay,SharePreference.toyyibsuccessurl).toString()
                val failuri = SharePreference.getStringPref(this@ActToyyibpay,SharePreference.toyyibcancelurl).toString()
                if (url?.contains(successuri) == true){
                    val billcode = SharePreference.getStringPref(this@ActToyyibpay,SharePreference.billcode).toString()
                    val transaction_id = url?.replace(successuri,"").replace("?status_id=1&billcode=","")?.replace(billcode,"")?.replace("&order_id=&msg=ok&transaction_id=","")
                    val intent = Intent()
                    intent.putExtra("id1", transaction_id)
                    setResult(0, intent)
                    finish()
                }
                else if (url?.contains(failuri) == true){
                    finish()
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (!redirect) {
                    loadingFinished = true

                    //HIDE LOADING IT HAS FINISHED
                } else {
                    redirect = false
                }
            }
        }
    }

}