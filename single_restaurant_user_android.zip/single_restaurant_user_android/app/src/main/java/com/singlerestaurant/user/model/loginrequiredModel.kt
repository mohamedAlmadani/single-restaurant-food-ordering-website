package com.singlerestaurant.user.model

import com.google.gson.annotations.SerializedName

data class LoginrequiredModel(

	@field:SerializedName("is_login_required")
	val isLoginRequired: String? = null,

	@field:SerializedName("session_id")
	val sessionId: String? = null,

	@field:SerializedName("message")
	val message: String? = null,

	@field:SerializedName("status")
	val status: Int? = null
)
