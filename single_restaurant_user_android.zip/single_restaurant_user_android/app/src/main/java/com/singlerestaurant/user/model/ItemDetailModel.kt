package com.singlerestaurant.user.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize


data class ItemDetailModel(

	@field:SerializedName("data")
	val data: FoodItemData? = null,

	@field:SerializedName("relateditems")
	val relateditems: ArrayList<RelateditemsItem>? = null,

	@field:SerializedName("message")
	val message: String? = null,

	@field:SerializedName("status")
	val status: Int? = null
)

/*
data class VariationItem(

	@field:SerializedName("item_id")
	val itemId: Int? = null,

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("product_price")
	val productPrice: String? = null,

	@field:SerializedName("sale_price")
	val salePrice: String? = null,

	@field:SerializedName("variation")
	val variation: String? = null
)
*/

data class FoodItemData(

	@field:SerializedName("is_cart")
	val isCart: String? = null,

	@field:SerializedName("category_info")
	val categoryInfo: CategoryInfo? = null,

	@field:SerializedName("is_favorite")
	val isFavorite: String? = null,

	@field:SerializedName("addons")
	val addons: ArrayList<AddOnsDataModel>? = null,

	@field:SerializedName("item_type")
	val itemType: String? = null,

	@field:SerializedName("item_name")
	val itemName: String? = null,

	@field:SerializedName("tax")
	val tax: String? = null,

	@field:SerializedName("has_variation")
	val hasVariation: String? = null,

	@field:SerializedName("subcategory_info")
	val subcategoryInfo: SubcategoryInfo? = null,

	@field:SerializedName("variation")
	val variation: ArrayList<VariationItem>? = null,

	@field:SerializedName("price")
	val price: String? = null,

	@field:SerializedName("preparation_time")
	val preparationTime: String? = null,

	@field:SerializedName("item_images")
	val itemImages: ArrayList<ItemImagesItem>? = null,

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("attribute")
	val attribute: String? = null,

	@field:SerializedName("item_description")
	val itemDescription: String? = null,

	@field:SerializedName("item_qty")
	val itemQty: Int? = null
)
/*
data class SubcategoryInfo(

	@field:SerializedName("subcategory_name")
	val subcategoryName: String? = null,

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("slug")
	val slug: String? = null
)*/


data class RelateditemsItem(

	@field:SerializedName("is_cart")
	var isCart: String? = null,

	@field:SerializedName("category_info")
	val categoryInfo: CategoryInfo? = null,

	@field:SerializedName("is_favorite")
	var isFavorite: String? = null,

	@field:SerializedName("addons")
	val addons: ArrayList<AddOnsDataModel>? = null,

	@field:SerializedName("item_type")
	val itemType: String? = null,

	@field:SerializedName("image_url")
	val imageUrl: String? = null,

	@field:SerializedName("available_qty")
	val availableQty: String? = null,

	@field:SerializedName("item_name")
	val itemName: String? = null,

	@field:SerializedName("tax")
	val tax: String? = null,

	@field:SerializedName("has_variation")
	val hasVariation: String? = null,

	@field:SerializedName("subcategory_info")
	val subcategoryInfo: SubcategoryInfo? = null,

	@field:SerializedName("variation")
	val variation:ArrayList<VariationItem>? = null,

	@field:SerializedName("image_name")
	val imageName: String? = null,

	@field:SerializedName("price")
	val price: String? = null,

	@field:SerializedName("preparation_time")
	val preparationTime: String? = null,

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("attribute")
	val attribute: String? = null,

	@field:SerializedName("item_description")
	val itemDescription: String? = null,

	@field:SerializedName("item_qty")
	var itemQty: String? = null
)

/*data class CategoryInfo(

	@field:SerializedName("category_name")
	val categoryName: String? = null,

	@field:SerializedName("image_url")
	val imageUrl: String? = null,

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("slug")
	val slug: String? = null
)*/
@Parcelize
data class ItemImagesItem(

	@field:SerializedName("image_name")
	val imageName: String? = null,

	@field:SerializedName("item_id")
	val itemId: Int? = null,

	@field:SerializedName("image_url")
	val imageUrl: String? = null,

	@field:SerializedName("id")
	val id: Int? = null
):Parcelable

data class AddonsItem(

	@field:SerializedName("price")
	val price: String? = null,

	@field:SerializedName("name")
	val name: String? = null,

	@field:SerializedName("id")
	val id: Int? = null
)
