package com.singlerestaurant.user.model

import com.google.gson.annotations.SerializedName

data class ToyyibpayModel(

	@field:SerializedName("redirecturl")
	val redirecturl: String? = null,

	@field:SerializedName("successurl")
	val successurl: String? = null,

	@field:SerializedName("message")
	val message: String? = null,

	@field:SerializedName("status")
	val status: Int? = null,

	@field:SerializedName("failureurl")
	val failureurl: String? = null,

	@field:SerializedName("billcode")
	val billcode: String? = null,

)
