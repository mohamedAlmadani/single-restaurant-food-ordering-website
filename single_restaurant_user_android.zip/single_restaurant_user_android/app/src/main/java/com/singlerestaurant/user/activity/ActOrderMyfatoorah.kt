package com.singlerestaurant.user.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.ColorRes
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.gson.Gson
import com.myfatoorah.sdk.entity.executepayment.MFExecutePaymentRequest
import com.myfatoorah.sdk.entity.executepayment_cardinfo.MFCardInfo
import com.myfatoorah.sdk.entity.executepayment_cardinfo.MFDirectPaymentResponse
import com.myfatoorah.sdk.entity.initiatepayment.MFInitiatePaymentRequest
import com.myfatoorah.sdk.entity.initiatepayment.MFInitiatePaymentResponse
import com.myfatoorah.sdk.entity.initiatepayment.PaymentMethod
import com.myfatoorah.sdk.entity.initiatesession.MFInitiateSessionRequest
import com.myfatoorah.sdk.entity.paymentstatus.MFGetPaymentStatusRequest
import com.myfatoorah.sdk.entity.paymentstatus.MFGetPaymentStatusResponse
import com.myfatoorah.sdk.entity.sendpayment.MFSendPaymentRequest
import com.myfatoorah.sdk.entity.sendpayment.MFSendPaymentResponse
import com.myfatoorah.sdk.enums.*
import com.myfatoorah.sdk.views.MFResult
import com.myfatoorah.sdk.views.MFSDK
import com.singlerestaurant.user.R
import com.singlerestaurant.user.adaptor.MyItemRecyclerViewAdapter
import com.singlerestaurant.user.api.ApiClient
import com.singlerestaurant.user.api.SingleResponsee
import com.singlerestaurant.user.databinding.ActMyfatoorahBinding
import com.singlerestaurant.user.remote.NetworkResponse
import com.singlerestaurant.user.utils.Common
import com.singlerestaurant.user.utils.OnListFragmentInteractionListener
import com.singlerestaurant.user.utils.SharePreference
import kotlinx.coroutines.launch
import java.util.*
import kotlin.collections.ArrayList

class ActOrderMyfatoorah : AppCompatActivity(), View.OnClickListener,
    OnListFragmentInteractionListener {

    private lateinit var binding: ActMyfatoorahBinding
    private lateinit var adapter: MyItemRecyclerViewAdapter
    private var selectedPaymentMethod: PaymentMethod? = null
    private val TAG = ActMyfatoorah::class.java.simpleName
    private var listener: OnListFragmentInteractionListener? = null
    var API_KEY = ""
    var transactionId = ""

    override fun onListFragmentInteraction(position: Int, paymentMethod: PaymentMethod) {

        selectedPaymentMethod = paymentMethod
        adapter.changeSelected(position)

        if (paymentMethod.directPayment)
            binding.llDirectPaymentLayout.visibility = View.VISIBLE
        else
            binding.llDirectPaymentLayout.visibility = View.GONE
    }

    override fun onClick(v: View?) {
        when (v!!.id) {
            R.id.btPay -> {
                if (selectedPaymentMethod == null) {
                    showAlertDialog("Please select payment method first")
                    return
                }

                if (!selectedPaymentMethod?.directPayment!!)
                    executePayment(selectedPaymentMethod?.paymentMethodId!!)
                else {
                    when {
                        //   binding.etAmount.text.isEmpty() -> binding.etCardNumber.error = "Required"
                        binding.etCardNumber.text!!.isEmpty() -> binding.etCardNumber.error = "Required"
                        binding.etExpiryMonth.text!!.isEmpty() -> binding.etExpiryMonth.error = "Required"
                        binding.etExpiryYear.text!!.isEmpty() -> binding.etExpiryYear.error = "Required"
                        binding.etSecurityCode.text!!.isEmpty() -> binding.etSecurityCode.error = "Required"
                        binding.etCardHolderName.text!!.isEmpty() -> binding.etCardHolderName.error = "Required"
                        else -> executePaymentWithCardInfo(selectedPaymentMethod?.paymentMethodId!!)
                    }
                }
            }
            R.id.btSendPayment -> sendPayment()
            R.id.btValidatePaymentView -> validatePaymentView()
            R.id.btPayWithPaymentView -> payWithPaymentView()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActMyfatoorahBinding.inflate(layoutInflater)
        setContentView(binding.root)

        API_KEY = intent.getStringExtra("secret_key").toString()

        // TODO, don't forget to init the MyFatoorah SDK with this line
        MFSDK.init(API_KEY, MFCountry.KUWAIT, MFEnvironment.TEST)

        if (API_KEY.isEmpty()) {
            showAlertDialog("Missing API Key.. You can get it from here: https://myfatoorah.readme.io/docs/demo-information")
            return
        }

        initiateSession()

        // You can custom your action bar, but this is optional not required to set this line
        MFSDK.setUpActionBar(
            "MyFatoorah Payment", R.color.white,
            R.color.colorPrimaryblue, true
        )
        // To hide action bar
        // MFSDK.setUpActionBar(isShowToolBar = false)

        initListeners()
        // setPaymentStyle()
        initiatePayment()
    }

    private fun initListeners() {
        binding.btPay.setOnClickListener(this)
        binding.btSendPayment.setOnClickListener(this)
        binding.btValidatePaymentView.setOnClickListener(this)
        binding.btPayWithPaymentView.setOnClickListener(this)

        listener = this
    }

    private fun sendPayment() {
        binding.pbLoading.visibility = View.VISIBLE

        val invoiceAmount =  intent.getStringExtra("getAmount").toString().toDouble()
        val request = MFSendPaymentRequest(
            invoiceAmount,
            "Customer name", MFNotificationOption.LINK
        )

        request.customerEmail =
            "test@test.com" // The email required if you choose MFNotificationOption.ALL or MFNotificationOption.EMAIL
        request.customerMobile =
            "12345678" // The mobile required if you choose MFNotificationOption.ALL or MFNotificationOption.SMS
        request.mobileCountryCode = MFMobileISO.KUWAIT.code

        MFSDK.sendPayment(request, MFAPILanguage.EN) { result: MFResult<MFSendPaymentResponse> ->
            when (result) {
                is MFResult.Success -> {
                    Log.d(TAG, "Response: " + Gson().toJson(result.response))
                    showAlertDialog("Invoice created successfully")
                }
                is MFResult.Fail -> {
                    Log.d(TAG, "Fail1: " + Gson().toJson(result.error))
                    showAlertDialog("Invoice failed")
                }
                else -> {}
            }

            binding.pbLoading.visibility = View.GONE
        }
    }

    private fun initiatePayment() {
        binding.pbLoading.visibility = View.VISIBLE

        val invoiceAmount =  intent.getStringExtra("getAmount").toString().toDouble()
        val request = MFInitiatePaymentRequest(invoiceAmount, MFCurrencyISO.KUWAIT_KWD)

        MFSDK.initiatePayment(
            request,
            MFAPILanguage.EN
        ) { result: MFResult<MFInitiatePaymentResponse> ->
            when (result) {
                is MFResult.Success -> {
                    Log.d(TAG, "Response: " + Gson().toJson(result.response))
                    setAvailablePayments(result.response.paymentMethods!!)
                }
                is MFResult.Fail -> {
                    Log.d(TAG, "Fail2: " + Gson().toJson(result.error))
                }
                else -> {}
            }
            binding.pbLoading.visibility = View.GONE
        }
    }

    private fun callAddMoney() {
        val amount= intent.getStringExtra("getAmount") ?: "0.00"

        Common.showLoadingProgress(this@ActOrderMyfatoorah)
        val map = HashMap<String, String>()
        map["user_id"] = SharePreference.getStringPref(
            this@ActOrderMyfatoorah,
            SharePreference.userId
        )!!
        map["amount"] = intent.getStringExtra("getAmount")?.toDouble().toString()
        map["transaction_type"] = "8"
        map["transaction_id"] = transactionId
        map["card_number"] = ""
        map["card_exp_month"] = ""
        map["card_exp_year"] = ""
        map["card_cvc"] = ""

        lifecycleScope.launch {
            when (val response = ApiClient.getClient().addMoney(map)) {
                is NetworkResponse.Success -> {
                    val restResponse = response.body
                    Common.dismissLoadingProgress()
                    if (restResponse.status == 1) {

                        Common.showSuccessFullMsg(
                            this@ActOrderMyfatoorah,
                            response.body.message.toString()
                        )
                        finish()
                        val intent = Intent(this@ActOrderMyfatoorah, ActMyWallet::class.java)
                        SharePreference.setStringPref(
                            this@ActOrderMyfatoorah,
                            SharePreference.wallet,
                            response.body.totalWallet.toString() ?: "00"
                        )
                        intent.flags=Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                        intent.putExtra("walletAmount", response.body.totalWallet.toString())
                        intent.putExtra("AddMoneyPay",true)
                        startActivity(intent)
                    } else {
                        Common.showErrorFullMsg(
                            this@ActOrderMyfatoorah,
                            restResponse.message.toString()
                        )
                    }
                }
                is NetworkResponse.ApiError -> {
                    Common.dismissLoadingProgress()
                    Common.showErrorFullMsg(
                        this@ActOrderMyfatoorah,
                        response.body.message.toString().replace("\\n", System.lineSeparator())
                    )
                }
                is NetworkResponse.NetworkError -> {
                    Common.dismissLoadingProgress()
                    Common.showErrorFullMsg(
                        this@ActOrderMyfatoorah,
                        resources.getString(R.string.no_internet)
                    )
                }
                is NetworkResponse.UnknownError -> {
                    Common.dismissLoadingProgress()
                    Common.showErrorFullMsg(
                        this@ActOrderMyfatoorah,
                        resources.getString(R.string.error_msg)
                    )
                }
            }
        }

    }

    private fun executePayment(paymentMethod: Int) {

        val invoiceAmount = intent.getStringExtra("getAmount").toString().toDouble()
        val request = MFExecutePaymentRequest(paymentMethod, invoiceAmount)

//        request.recurringModel = RecurringModel(MFRecurringType.DAILY, 5)

        MFSDK.executePayment(
            this,
            request,
            MFAPILanguage.EN,
            onInvoiceCreated = {
                Log.d(TAG, "invoiceId: $it")
            }
        ) { invoiceId: String, result: MFResult<MFGetPaymentStatusResponse> ->
            when (result) {
                is MFResult.Success -> {
                    Log.d(TAG, "Response: " + Gson().toJson(result.response))
                    transactionId = result.response.invoiceTransactions?.get(0)?.transactionId.toString()
                    Log.d( "transactionId3..." ,transactionId)
                    Log.d( "successsss..." ,"payment sucesfull")
                    Log.d(TAG, "hellooo")
                    callAddMoney()

                }
                is MFResult.Fail -> {
                    Log.d(TAG, "Fail9: " + Gson().toJson(result.error))
                    showAlertDialog("Payment failed")
                }
                else -> {}
            }

            binding.pbLoading.visibility = View.GONE
        }
    }

    private fun executePaymentWithCardInfo(paymentMethod: Int) {
        binding.pbLoading.visibility = View.VISIBLE

        val invoiceAmount = intent.getStringExtra("getAmount").toString().toDouble()
        val request = MFExecutePaymentRequest(paymentMethod, invoiceAmount)

//        val mfCardInfo = MFCardInfo("Your token here")
        val mfCardInfo = MFCardInfo(
            binding.etCardNumber.text.toString(),
            binding.etExpiryMonth.text.toString(),
            binding.etExpiryYear.text.toString(),
            binding.etSecurityCode.text.toString(),
            binding.etCardHolderName.text.toString(),
            false,
            false
        )

        MFSDK.executeDirectPayment(
            this,
            request,
            mfCardInfo,
            MFAPILanguage.EN,
            onInvoiceCreated = {
                Log.d(TAG, "invoiceId: $it")
            }
        ) { invoiceId: String, result: MFResult<MFDirectPaymentResponse> ->
            when (result) {
                is MFResult.Success -> {

                    Log.d(TAG, "Response: " + Gson().toJson(result.response))
                    transactionId = result.response.mfPaymentStatusResponse.invoiceTransactions?.get(0)?.transactionId.toString()
                    Log.d( "transactionId2..." ,transactionId)
                    Log.d( "successsss..." ,"payment sucesfull")
                    callAddMoney()
                    /* val intent = Intent()
                     intent.putExtra("id", result.response.mfPaymentStatusResponse.invoiceTransactions?.get(0)?.transactionId)
                     setResult(RESULT_OK, intent)
                     Toast.makeText(this@ActMyfatoorah,"Payment done successfully",Toast.LENGTH_SHORT)*/
                }
                is MFResult.Fail -> {
                    Log.d(TAG, "Fail10: " + Gson().toJson(result.error))
                    showAlertDialog("Payment failed")
                }
                else -> {}
            }

            binding.pbLoading.visibility = View.GONE
        }
    }

    private fun cancelRecurringPayment() {
        binding.pbLoading.visibility = View.VISIBLE

        MFSDK.cancelRecurringPayment(
            "4WJpq0EmgROY/ynyADYwcA==",
            MFAPILanguage.EN
        ) { result: MFResult<Boolean> ->
            when (result) {
                is MFResult.Success -> {
                    Log.d(TAG, "Response: " + Gson().toJson(result.response))
                }
                is MFResult.Fail -> {
                    Log.d(TAG, "Fail3: " + Gson().toJson(result.error))
                }
                else -> {}
            }
            binding.pbLoading.visibility = View.GONE
        }
    }

    private fun cancelToken() {
        binding.pbLoading.visibility = View.VISIBLE

        MFSDK.cancelToken(
            "dFF2txV3SzqzQpWv9FAd7ILPPgetQ69BIjfVRQPWuIw=",
            MFAPILanguage.EN
        ) { result: MFResult<Boolean> ->
            when (result) {
                is MFResult.Success -> {
                    Log.d(TAG, "Response: " + Gson().toJson(result.response))
                }
                is MFResult.Fail -> {
                    Log.d(TAG, "Fail: " + Gson().toJson(result.error))
                }
                else -> {}
            }
            binding.pbLoading.visibility = View.GONE
        }
    }

    private fun getPaymentStatus() {
        binding.pbLoading.visibility = View.VISIBLE

        val request = MFGetPaymentStatusRequest(invoiceId = "12345")

        MFSDK.getPaymentStatus(
            request,
            MFAPILanguage.EN
        ) { result: MFResult<MFGetPaymentStatusResponse> ->
            when (result) {
                is MFResult.Success -> {
                    Log.d(TAG, "Response: " + Gson().toJson(result.response))
                }
                is MFResult.Fail -> {
                    Log.d(TAG, "Fail: " + Gson().toJson(result.error))
                }
                else -> {}
            }
            binding.pbLoading.visibility = View.GONE
        }
    }

    private fun setAvailablePayments(paymentMethods: ArrayList<PaymentMethod>) {
        adapter = MyItemRecyclerViewAdapter(this@ActOrderMyfatoorah ,paymentMethods, listener)
        binding.rvPaymentMethod.adapter = adapter
    }

    private fun showAlertDialog(text: String) {
        AlertDialog.Builder(this)
            .setMessage(text)
            .setPositiveButton(android.R.string.ok) { _, _ -> }
            .setIcon(android.R.drawable.ic_dialog_alert)
            .show()
    }

    private fun initiateSession() {
        /**
         * If you want to use saved card option with embedded payment, send the parameter
         * "customerIdentifier" with a unique value for each customer. This value cannot be used
         * for more than one Customer.
         */
        val mfInitiateSessionRequest = MFInitiateSessionRequest(customerIdentifier = "12332212")
        MFSDK.initiateSession(request = null) {
            when (it) {
                is MFResult.Success -> {
                    binding.mfPaymentView.load(
                        it.response,
                        onCardBinChanged = { bin ->
                            Log.d(TAG, "bin: $bin")
                        }
                    )
                }
                is MFResult.Fail -> {
                    Log.d(TAG, "Fail5: " + Gson().toJson(it.error))
                    showAlertDialog(Gson().toJson(it.error))
                }
                else -> {}
            }
        }
    }

    private fun validatePaymentView() {
        binding.mfPaymentView.validate { result: MFResult<String> ->
            when (result) {
                is MFResult.Success -> {
                    Log.d(TAG, "Response: " + Gson().toJson(result.response))
                    payWithPaymentView()
                }
                is MFResult.Fail -> {
                    Log.d(TAG, "Fail:7 " + Gson().toJson(result.error))
                    showAlertDialog("Fail: " + Gson().toJson(result.error))
                }
                else -> {}
            }
        }
    }

    private fun payWithPaymentView() {
        val invoiceAmount =  intent.getStringExtra("getAmount").toString().toDouble()
        val request = MFExecutePaymentRequest(invoiceAmount)

        binding.mfPaymentView.pay(
            this,
            request,
            MFAPILanguage.EN,
            onInvoiceCreated = {
                Log.d(TAG, "invoiceId: $it")
            }
        ) { invoiceId: String, result: MFResult<MFGetPaymentStatusResponse> ->
            when (result) {
                is MFResult.Success -> {
                    Log.d(TAG, "Response: " + Gson().toJson(result.response))

                    transactionId = result.response.invoiceTransactions?.get(0)?.transactionId.toString()
                    Log.d( "transactionId..." ,transactionId)
                    Log.d( "successsss..." ,"payment sucesfull")
                    callAddMoney()
                    /*  val intent = Intent()
                      intent.putExtra("id", result.response.invoiceTransactions?.get(0)?.transactionId)
                      setResult(RESULT_OK, intent)
                      Toast.makeText(this@ActMyfatoorah,"Payment done successfully",Toast.LENGTH_SHORT)*/
                }
                is MFResult.Fail -> {
                    Log.d(TAG, "Fail8: " + Gson().toJson(result.error))
                    showAlertDialog(Gson().toJson(result.error))
                }
                else -> {}
            }

            binding.pbLoading.visibility = View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        binding.mfPaymentView.enableCardNFC(this)
    }

    public override fun onPause() {
        super.onPause()
        binding.mfPaymentView.disableCardNFC(this)
    }

    public override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        binding.mfPaymentView.readCard(intent)
    }

}