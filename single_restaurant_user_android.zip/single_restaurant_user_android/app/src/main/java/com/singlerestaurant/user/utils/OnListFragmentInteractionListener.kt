package com.singlerestaurant.user.utils

import com.myfatoorah.sdk.entity.initiatepayment.PaymentMethod

interface OnListFragmentInteractionListener {
    fun onListFragmentInteraction(position: Int, item: PaymentMethod)
}