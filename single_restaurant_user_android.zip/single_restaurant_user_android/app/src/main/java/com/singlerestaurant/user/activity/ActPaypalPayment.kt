package com.singlerestaurant.user.activity

import android.R
import android.R.attr.data
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.paypal.android.sdk.payments.PayPalConfiguration
import com.paypal.android.sdk.payments.PayPalPayment
import com.paypal.android.sdk.payments.PayPalService
import com.paypal.android.sdk.payments.PaymentActivity
import com.paypal.android.sdk.payments.PaymentConfirmation
import com.singlerestaurant.user.databinding.ActPaypalBinding
import org.json.JSONException
import org.json.JSONObject
import java.math.BigDecimal


@Suppress("DEPRECATION")
class ActPaypalPayment : AppCompatActivity() {
    private lateinit var _binding:ActPaypalBinding

    val clientKey = "AcRx7vvy79nbNxBemacGKmnnRe_CtxkItyspBS_eeMIPREwfCEIfPg1uX-bdqPrS_ZFGocxEH_SJRrIJ"
    val PAYPAL_REQUEST_CODE = 123

    // Paypal Configuration Object
    private val config = PayPalConfiguration() // Start with mock environment.  When ready,
        // switch to sandbox (ENVIRONMENT_SANDBOX)
        // or live (ENVIRONMENT_PRODUCTION)
        .environment(PayPalConfiguration.ENVIRONMENT_SANDBOX) // on below line we are passing a client id.
        .clientId(clientKey)
   /* private var amountEdt: EditText? = null
    private var paymentTV: TextView? = null
*/
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActPaypalBinding.inflate(layoutInflater)
        setContentView(_binding.root)

       getPayment()
    }

    private fun getPayment() {
        val amount = intent.getStringExtra("amount")
        val currency = intent.getStringExtra("currency")

        val payment = PayPalPayment(BigDecimal(amount), currency, "Course Fees",
            PayPalPayment.PAYMENT_INTENT_SALE)

        val intent = Intent(this, PaymentActivity::class.java)
        Log.d("hello1","huy")
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, config)
        Log.d("hello2","huy")
        intent.putExtra(PaymentActivity.EXTRA_PAYMENT, payment)
        Log.d("hello3","huy")
        startActivityForResult(intent, PAYPAL_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("hello4","huy")
        Log.d("requestCode", requestCode.toString())

        if (requestCode === PAYPAL_REQUEST_CODE) {
            Log.d("hello","huy")
            // If the result is OK i.e. user has not canceled the payment
            if (resultCode === Activity.RESULT_OK) {

                // Getting the payment confirmation
                val confirm: PaymentConfirmation? =
                    data?.getParcelableExtra(PaymentActivity.EXTRA_RESULT_CONFIRMATION)

                // if confirmation is not null
                if (confirm != null) {
                    try {
                        // Getting the payment details
                        val paymentDetails = confirm.toJSONObject().toString(4)
                        // on below line we are extracting json response and displaying it in a text view.
                        val payObj = JSONObject(paymentDetails)
                        val payID = payObj.getJSONObject("response").getString("id")
                        val state = payObj.getJSONObject("response").getString("state")
                      //  _binding.idTVStatus!!.text = "Payment $state\n with payment id is $payID"
                        val intent = Intent()
                        intent.putExtra("id", payID)
                        setResult(RESULT_OK, intent)
                        finish()
                    } catch (e: JSONException) {
                        // handling json exception on below line
                        Log.e("Error", "an extremely unlikely failure occurred: ", e)
                    }
                }
            } else if (resultCode === Activity.RESULT_CANCELED) {
                // on below line we are checking the payment status.
                Log.i("paymentExample", "The user canceled.")
            } else if (resultCode === PaymentActivity.RESULT_EXTRAS_INVALID) {
                // on below line when the invalid paypal config is submitted.
                Log.i("paymentExample",
                    "An invalid Payment or PayPalConfiguration was submitted. Please see the docs.")
            }
        }

    }

}