package com.singlerestaurant.user.adaptor

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.facebook.appevents.ml.Utils
import com.singlerestaurant.user.R
import com.singlerestaurant.user.databinding.RowPaymentListBinding
import com.singlerestaurant.user.model.PaymentmethodsItem
import com.singlerestaurant.user.utils.Common
import com.singlerestaurant.user.utils.Constants
import com.singlerestaurant.user.utils.SharePreference


class PaymentListAdapter(
    private val context: Activity,
    private val paymentOptionList: ArrayList<PaymentmethodsItem>,
    private val itemClick: (Int, String) -> Unit,
) : RecyclerView.Adapter<PaymentListAdapter.PaymentViewHolder>() {
    var walletAmount=""

    inner class PaymentViewHolder(private val itemBinding: RowPaymentListBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(
            data: PaymentmethodsItem,
            context: Activity,
            position: Int,
            itemClick: (Int, String) -> Unit
        ) = with(itemBinding)
        {
            val currency = SharePreference.getStringPref(context, SharePreference.isCurrancy) ?: ""
            val currencyPos = SharePreference.getStringPref(context, SharePreference.CurrencyPosition) ?: ""

            if (data.isSelect) {
                itemBinding.ivCheck.visibility = View.VISIBLE
            } else {
                itemBinding.ivCheck.visibility = View.GONE
            }


            Glide.with(itemView.context).load(data.image).into(itemBinding.ivPaymentProfile)
            if(data.paymentName=="Wallet")
            {
                itemBinding.tvPaymentName.text = data.paymentName.plus(" (${Common.getPrices(currencyPos,currency,walletAmount)})")

            }else
            {
                itemBinding.tvPaymentName.text = data.paymentName

            }
            itemView.setOnClickListener {
                itemClick(position, Constants.ItemClick)
                for (i in 0 until paymentOptionList.size) {
                    paymentOptionList[i].isSelect = false
                }
                data.isSelect = true
                notifyDataSetChanged()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PaymentViewHolder {
        val view = RowPaymentListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PaymentViewHolder(view)
    }

    override fun onBindViewHolder(holder: PaymentViewHolder, position: Int) {
        holder.bind(paymentOptionList[position], context, position, itemClick)
    }

    override fun getItemCount(): Int {
        return paymentOptionList.size
    }
    fun setupWalletAmount(walletAmount:String)
    {
        this.walletAmount=walletAmount
    }
}