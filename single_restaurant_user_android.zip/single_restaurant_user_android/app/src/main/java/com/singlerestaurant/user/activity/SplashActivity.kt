package com.singlerestaurant.user.activity


import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import androidx.lifecycle.lifecycleScope
import com.singlerestaurant.user.base.BaseActivity
import com.singlerestaurant.user.databinding.ActivitySplashBinding
import com.singlerestaurant.user.utils.Common
import com.singlerestaurant.user.utils.Common.printKeyHash
import com.singlerestaurant.user.utils.Constants
import com.singlerestaurant.user.utils.SharePreference
import com.singlerestaurant.user.utils.SharePreference.Companion.getBooleanPref
import com.google.firebase.messaging.FirebaseMessaging
import com.singlerestaurant.user.R
import com.singlerestaurant.user.api.ApiClient
import com.singlerestaurant.user.remote.NetworkResponse
import com.singlerestaurant.user.utils.SharePreference.Companion.sessionid
import kotlinx.coroutines.launch


@SuppressLint("CustomSplashScreen")
class SplashActivity : BaseActivity() {
    private lateinit var binding: ActivitySplashBinding
    override fun setLayout(): View {
        return binding.root
    }

    override fun InitView() {
        binding = ActivitySplashBinding.inflate(layoutInflater)
        Common.getLog("getShaKey", printKeyHash(this@SplashActivity)!!)
        Common.getCurrentLanguage(this@SplashActivity, false)
        callLoginReduries()
        var strToken = ""
        FirebaseMessaging.getInstance().token.addOnCompleteListener {
            strToken = it.result
        }
        Common.getLog("Token== ", strToken)
        Common.getLog("Token== ", getBooleanPref(this@SplashActivity, SharePreference.isTutorial).toString())
        var sessionid = SharePreference.getStringPref(this, SharePreference.sessionid).toString()
    }

    private fun callLoginReduries() {

        lifecycleScope.launch {
            when (val response = ApiClient.getClient().Loginrequired()) {
                is NetworkResponse.Success -> {
                 //   Common.dismissLoadingProgress()
                    val responseBody = response.body
                    when(response.body.status){
                        1->{
                            SharePreference.setStringPref(this@SplashActivity,SharePreference.isloginrequired,response.body.isLoginRequired.toString())
                            if (sessionid.isNullOrEmpty()){
                                SharePreference.setStringPref(this@SplashActivity,SharePreference.sessionid,response.body.sessionId.toString())
                                Log.d("guestid3",response.body.sessionId.toString())
                            }else{
                                SharePreference.getStringPref(this@SplashActivity,SharePreference.sessionid)
                            }
                            Log.d("guestid",response.body.sessionId.toString())
                            Log.d("guestid",SharePreference.getStringPref(this@SplashActivity,SharePreference.sessionid).toString())

                            Handler(Looper.getMainLooper()).postDelayed({
                                if (!getBooleanPref(this@SplashActivity, SharePreference.isTutorial)) {
                                    openActivity(TutorialActivity::class.java)
                                    finish()
                                } else {
                                    if (intent.getStringExtra("type").toString() == "promotion") {
                                        if (!intent.getStringExtra("category_id").isNullOrEmpty()) {
                                            val actIntent = Intent(this@SplashActivity, ActSubCategoryProducts::class.java)
                                            actIntent.putExtra("category_id", intent.getStringExtra("category_id").toString())
                                            actIntent.putExtra(Constants.FromNotification,true)
                                            actIntent.putExtra("category_name", intent.getStringExtra("category_name").toString())
                                            startActivity(actIntent)
                                        } else if (!intent.getStringExtra("item_id").isNullOrEmpty()) {
                                            val orderIntent = Intent(this@SplashActivity, ActFoodDetails::class.java)
                                            orderIntent.putExtra(Constants.FromNotification,true)
                                            orderIntent.putExtra("foodItemId", intent.getStringExtra("item_id").toString())
                                            startActivity(orderIntent)
                                        } else {
                                            val intent = Intent(this@SplashActivity, DashboardActivity::class.java)
                                            startActivity(intent)
                                        }
                                    } else if (intent.getStringExtra("type").toString() == "order") {
                                        val detailIntent = Intent(this@SplashActivity, OrderDetailActivity::class.java)
                                        detailIntent.putExtra("order_id", intent.getStringExtra("order_id").toString())
                                        detailIntent.putExtra(Constants.FromNotification,true)
                                        startActivity(detailIntent)
                                    } else if (intent.getStringExtra("type").toString() == "wallet") {
                                        val walletIntent=Intent(this@SplashActivity,ActTransactionHistory::class.java)
                                        walletIntent.putExtra(Constants.FromNotification,true)
                                        startActivity(walletIntent)
                                    } else {
                                        openActivity(DashboardActivity::class.java)
                                    }
                                    finish()
                                }
                            }, 3000)


                        }
                    }
                }
                is NetworkResponse.ApiError -> {
                    Common.dismissLoadingProgress()
                    Common.showErrorFullMsg(
                        this@SplashActivity,
                        response.body.message.toString().replace("\\n", System.lineSeparator())
                    )
                }
                is NetworkResponse.NetworkError -> {
                    Common.dismissLoadingProgress()
                    Common.showErrorFullMsg(
                        this@SplashActivity,
                        resources.getString(R.string.no_internet)
                    )
                }
                is NetworkResponse.UnknownError -> {
                    Common.dismissLoadingProgress()
                    Common.showErrorFullMsg(
                        this@SplashActivity,
                        resources.getString(R.string.error_msg)
                    )
                }

            }
        }

    }


    override fun onResume() {
        super.onResume()
        Common.getCurrentLanguage(this@SplashActivity, false)
    }
}