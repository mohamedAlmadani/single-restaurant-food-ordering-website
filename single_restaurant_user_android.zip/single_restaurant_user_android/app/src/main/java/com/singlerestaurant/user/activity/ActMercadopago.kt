package com.singlerestaurant.user.activity

import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import com.singlerestaurant.user.R
import com.singlerestaurant.user.databinding.ActMercadopagoBinding
import com.singlerestaurant.user.utils.SharePreference

class ActMercadopago : AppCompatActivity() {
    private lateinit var binding:ActMercadopagoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActMercadopagoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.webView.settings.loadsImagesAutomatically = true
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY

        var loadingFinished = true
        var redirect = false
        var uri = SharePreference.getStringPref(this@ActMercadopago, SharePreference.mercadopagopayurl).toString()

        var preferenceid = uri.replace("https://sandbox.mercadopago.com.br/checkout/v1/redirect?pref_id=","")
        Log.d("preferenceid..",preferenceid)
        Log.d("uriiii",uri)
        binding.webView.loadUrl(uri)
        binding.webView.webViewClient = object : WebViewClient() {
         /*    override fun shouldOverrideUrlLoading(
                 view: WebView,
                 uri: String,
             ): Boolean {
                 if (!loadingFinished) {
                     redirect = true
                 }
                 loadingFinished = false
                 binding.webView.loadUrl(uri)
                 return true
             }*/

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                loadingFinished = false
                val successuri= SharePreference.getStringPref(this@ActMercadopago,SharePreference.mercadopagosuccessurl).toString()
                val failuri = SharePreference.getStringPref(this@ActMercadopago,SharePreference.mercadopagocancelurl).toString()
                if (url?.contains(successuri) == true){
                    var inputstring = url.toString()
                    inputstring = inputstring.substring(inputstring.indexOf("?") + 1 , inputstring.indexOf("&"))
                    val transaction_id = inputstring.replace("collection_id=","")
                    val intent = Intent()
                    intent.putExtra("id2", transaction_id)
                    setResult(1, intent)
                    finish()
                }
                else if (url?.contains(failuri) == true){
                    finish()
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (!redirect) {
                    loadingFinished = true

                    //HIDE LOADING IT HAS FINISHED
                } else {
                    redirect = false
                }
            }
        }

    }
}