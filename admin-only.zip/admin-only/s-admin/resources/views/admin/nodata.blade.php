<div class="d-grid justify-content-center my-3">

    <img src="{{Helper::web_image_path('nodata.svg')}}" alt="" class="mx-auto mb-3 w-75">

</div>