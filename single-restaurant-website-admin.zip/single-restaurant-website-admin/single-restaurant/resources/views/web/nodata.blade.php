<div class="d-grid justify-items-center my-3">
    <img src="{{Helper::web_image_path('nodata.svg')}}" alt="" class="mb-3 w-100">
</div>