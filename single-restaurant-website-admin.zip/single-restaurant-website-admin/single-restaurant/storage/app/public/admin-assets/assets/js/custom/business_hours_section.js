// Business Hours
$(document).ready(function() {
  $("#start_monday").timepicker();
  $("#end_monday").timepicker();
  $("#start_tuesday").timepicker();
  $("#end_tuesday").timepicker();
  $("#start_wednesday").timepicker();
  $("#end_wednesday").timepicker();
  $("#start_thursday").timepicker();
  $("#end_thursday").timepicker();
  $("#start_friday").timepicker();
  $("#end_friday").timepicker();
  $("#start_saturday").timepicker();
  $("#end_saturday").timepicker();
  $("#start_sunday").timepicker();
  $("#end_sunday").timepicker();
});
